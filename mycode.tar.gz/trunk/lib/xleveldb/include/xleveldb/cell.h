// cell.h (2013-06-18)
// Li Xinjie (xjason.li@gmail.com)

#ifndef STORAGE_XLEVELDB_INCLUDE_CELL_H_
#define STORAGE_XLEVELDB_INCLUDE_CELL_H_

#include "xleveldb/slice.h"

namespace xleveldb {

struct Cell {
  Slice row;
  Slice col;

  Cell() { }
  Cell(const Slice& r): row(r), col() { }
  Cell(const Slice& r, const Slice& c): row(r), col(c) { }
};

} // namespace xleveldb

#endif // STORAGE_XLEVELDB_INCLUDE_CELL_H_
