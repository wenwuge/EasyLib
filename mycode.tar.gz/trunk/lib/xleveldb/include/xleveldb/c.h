/* Copyright (c) 2011 The LevelDB Authors. All rights reserved.
  Use of this source code is governed by a BSD-style license that can be
  found in the LICENSE file. See the AUTHORS file for names of contributors.

  C bindings for leveldb.  May be useful as a stable ABI that can be
  used by programs that keep leveldb in a shared library, or for
  a JNI api.

  Does not support:
  . getters for the option types
  . custom comparators that implement key shortening
  . capturing post-write-snapshot
  . custom iter, db, env, cache implementations using just the C bindings

  Some conventions:

  (1) We expose just opaque struct pointers and functions to clients.
  This allows us to change internal representations without having to
  recompile clients.

  (2) For simplicity, there is no equivalent to the Slice type.  Instead,
  the caller has to pass the pointer and length as separate
  arguments.

  (3) Errors are represented by a null-terminated c string.  NULL
  means no error.  All operations that can raise an error are passed
  a "char** errptr" as the last argument.  One of the following must
  be true on entry:
     *errptr == NULL
     *errptr points to a malloc()ed null-terminated error message
       (On Windows, *errptr must have been malloc()-ed by this library.)
  On success, a leveldb routine leaves *errptr unchanged.
  On failure, leveldb frees the old value of *errptr and
  set *errptr to a malloc()ed error message.

  (4) Bools have the type unsigned char (0 == false; rest == true)

  (5) All of the pointer arguments must be non-NULL.
*/

#ifndef STORAGE_XLEVELDB_INCLUDE_C_H_
#define STORAGE_XLEVELDB_INCLUDE_C_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>

/* Exported types */

typedef struct xleveldb_t               xleveldb_t;
typedef struct xleveldb_cache_t         xleveldb_cache_t;
typedef struct xleveldb_comparator_t    xleveldb_comparator_t;
typedef struct xleveldb_env_t           xleveldb_env_t;
typedef struct xleveldb_filelock_t      xleveldb_filelock_t;
typedef struct xleveldb_filterpolicy_t  xleveldb_filterpolicy_t;
typedef struct xleveldb_db_iterator_t   xleveldb_db_iterator_t;
typedef struct xleveldb_iterator_t      xleveldb_iterator_t;
typedef struct xleveldb_logger_t        xleveldb_logger_t;
typedef struct xleveldb_options_t       xleveldb_options_t;
typedef struct xleveldb_randomfile_t    xleveldb_randomfile_t;
typedef struct xleveldb_readoptions_t   xleveldb_readoptions_t;
typedef struct xleveldb_seqfile_t       xleveldb_seqfile_t;
typedef struct xleveldb_snapshot_t      xleveldb_snapshot_t;
typedef struct xleveldb_writablefile_t  xleveldb_writablefile_t;
typedef struct xleveldb_writebatch_t    xleveldb_writebatch_t;
typedef struct xleveldb_writeoptions_t  xleveldb_writeoptions_t;

/* DB operations */

extern xleveldb_t* xleveldb_open(
    const xleveldb_options_t* options,
    const char* name,
    char** errptr);

extern void xleveldb_close(xleveldb_t* db);

extern void xleveldb_put(
    xleveldb_t* db,
    const xleveldb_writeoptions_t* options,
    const char* key, size_t keylen,
    const char* col, size_t collen,
    const char* val, size_t vallen,
    uint64_t* seq, uint64_t ttl,
    char** errptr);

extern void xleveldb_delete(
    xleveldb_t* db,
    const xleveldb_writeoptions_t* options,
    const char* key, size_t keylen,
    const char* col, size_t collen,
    uint64_t* seq,
    char** errptr);

extern void xleveldb_write(
    xleveldb_t* db,
    const xleveldb_writeoptions_t* options,
    xleveldb_writebatch_t* batch,
    char** errptr);

/* Returns NULL if not found.  A malloc()ed array otherwise.
   Stores the length of the array in *vallen. */
extern char* xleveldb_get(
    xleveldb_t* db,
    const xleveldb_readoptions_t* options,
    const char* key, size_t keylen,
    const char* col, size_t collen,
    size_t* vallen,
    uint64_t* seq, 
    uint64_t* ttl,
    char** errptr);

extern xleveldb_db_iterator_t* xleveldb_create_iterator(
    xleveldb_t* db,
    const xleveldb_readoptions_t* options);

extern const xleveldb_snapshot_t* xleveldb_create_snapshot(
    xleveldb_t* db);

extern void xleveldb_release_snapshot(
    xleveldb_t* db,
    const xleveldb_snapshot_t* snapshot);

/* Returns NULL if property name is unknown.
   Else returns a pointer to a malloc()-ed null-terminated value. */
extern char* xleveldb_property_value(
    xleveldb_t* db,
    const char* propname);

extern void xleveldb_approximate_sizes(
    xleveldb_t* db,
    int num_ranges,
    const char* const* range_start_key, const size_t* range_start_key_len,
    const char* const* range_limit_key, const size_t* range_limit_key_len,
    uint64_t* sizes);

extern void xleveldb_compact_range(
    xleveldb_t* db,
    const char* start_key, size_t start_key_len,
    const char* start_col, size_t start_col_len,
    const char* limit_key, size_t limit_key_len,
    const char* limit_col, size_t limit_col_len);

/* Management operations */

extern void xleveldb_destroy_db(
    const xleveldb_options_t* options,
    const char* name,
    char** errptr);

extern void xleveldb_repair_db(
    const xleveldb_options_t* options,
    const char* name,
    char** errptr);

/* Iterator */

extern void xleveldb_iter_destroy(xleveldb_iterator_t*);
extern unsigned char xleveldb_iter_valid(const xleveldb_iterator_t*);
extern void xleveldb_iter_seek_to_first(xleveldb_iterator_t*);
extern void xleveldb_iter_seek_to_last(xleveldb_iterator_t*);
extern void xleveldb_iter_seek(xleveldb_iterator_t*, const char* k, size_t klen);
extern void xleveldb_iter_next(xleveldb_iterator_t*);
extern void xleveldb_iter_prev(xleveldb_iterator_t*);
extern const char* xleveldb_iter_key(const xleveldb_iterator_t*, size_t* klen);
extern uint64_t xleveldb_iter_flag(const xleveldb_iterator_t*);
extern const char* xleveldb_iter_value(const xleveldb_iterator_t*, size_t* vlen);
extern void xleveldb_iter_get_error(const xleveldb_iterator_t*, char** errptr);

extern void xleveldb_db_iter_destroy(xleveldb_db_iterator_t*);
extern unsigned char xleveldb_db_iter_valid(const xleveldb_db_iterator_t*);
extern void xleveldb_db_iter_seek_to_first(xleveldb_db_iterator_t*);
extern void xleveldb_db_iter_seek_to_last(xleveldb_db_iterator_t*);
extern void xleveldb_db_iter_seek(xleveldb_db_iterator_t*, const char* k, size_t klen);
extern void xleveldb_db_iter_next(xleveldb_db_iterator_t*);
extern void xleveldb_db_iter_prev(xleveldb_db_iterator_t*);
extern const char* xleveldb_db_iter_row(const xleveldb_db_iterator_t*, size_t* rlen);
extern const char* xleveldb_db_iter_col(const xleveldb_db_iterator_t*, size_t* clen);
extern uint64_t xleveldb_db_iter_ttl(const xleveldb_db_iterator_t*);
extern const char* xleveldb_db_iter_value(const xleveldb_db_iterator_t*, size_t* vlen);
extern void xleveldb_db_iter_get_error(const xleveldb_db_iterator_t*, char** errptr);

/* Write batch */

extern xleveldb_writebatch_t* xleveldb_writebatch_create();
extern void xleveldb_writebatch_destroy(xleveldb_writebatch_t*);
extern void xleveldb_writebatch_clear(xleveldb_writebatch_t*);
extern void xleveldb_writebatch_put(
    xleveldb_writebatch_t*,
    const char* key, size_t klen,
    const char* col, size_t clen,
    const char* val, size_t vlen,
    uint64_t ttl);
extern void xleveldb_writebatch_delete(
    xleveldb_writebatch_t*,
    const char* key, size_t klen,
    const char* col, size_t clen);
extern void xleveldb_writebatch_iterate(
    xleveldb_writebatch_t*,
    void* state,
    void (*put)(void*, const char* k, size_t klen, const char* c, size_t clen, const char* v, size_t vlen, uint64_t ttl),
    void (*deleted)(void*, const char* k, size_t klen, const char* c, size_t clen));

/* Options */

extern xleveldb_options_t* xleveldb_options_create();
extern void xleveldb_options_destroy(xleveldb_options_t*);
extern void xleveldb_options_set_row_comparator(
    xleveldb_options_t*,
    xleveldb_comparator_t*);
extern void xleveldb_options_set_col_comparator(
    xleveldb_options_t*,
    xleveldb_comparator_t*);
extern void xleveldb_options_set_filter_policy(
    xleveldb_options_t*,
    xleveldb_filterpolicy_t*);
extern void xleveldb_options_set_create_if_missing(
    xleveldb_options_t*, unsigned char);
extern void xleveldb_options_set_error_if_exists(
    xleveldb_options_t*, unsigned char);
extern void xleveldb_options_set_paranoid_checks(
    xleveldb_options_t*, unsigned char);
extern void xleveldb_options_set_env(xleveldb_options_t*, xleveldb_env_t*);
extern void xleveldb_options_set_info_log(xleveldb_options_t*, xleveldb_logger_t*);
extern void xleveldb_options_set_write_buffer_size(xleveldb_options_t*, size_t);
extern void xleveldb_options_set_max_open_files(xleveldb_options_t*, int);
extern void xleveldb_options_set_cache(xleveldb_options_t*, xleveldb_cache_t*);
extern void xleveldb_options_set_block_size(xleveldb_options_t*, size_t);
extern void xleveldb_options_set_block_restart_interval(xleveldb_options_t*, int);

enum {
  xleveldb_no_compression = 0,
  xleveldb_snappy_compression = 1
};
extern void xleveldb_options_set_compression(xleveldb_options_t*, int);

/* Comparator */

extern xleveldb_comparator_t* xleveldb_comparator_create(
    void* state,
    void (*destructor)(void*),
    int (*compare)(
        void*,
        const char* a, size_t alen,
        const char* b, size_t blen),
    const char* (*name)(void*));
extern void xleveldb_comparator_destroy(xleveldb_comparator_t*);

/* Filter policy */

extern xleveldb_filterpolicy_t* xleveldb_filterpolicy_create(
    void* state,
    void (*destructor)(void*),
    char* (*create_filter)(
        void*,
        const char* const* key_array, const size_t* key_length_array,
        int num_keys,
        size_t* filter_length),
    unsigned char (*key_may_match)(
        void*,
        const char* key, size_t length,
        const char* filter, size_t filter_length),
    const char* (*name)(void*));
extern void xleveldb_filterpolicy_destroy(xleveldb_filterpolicy_t*);

extern xleveldb_filterpolicy_t* xleveldb_filterpolicy_create_bloom(
    int bits_per_key);

/* Read options */

extern xleveldb_readoptions_t* xleveldb_readoptions_create();
extern void xleveldb_readoptions_destroy(xleveldb_readoptions_t*);
extern void xleveldb_readoptions_set_verify_checksums(
    xleveldb_readoptions_t*,
    unsigned char);
extern void xleveldb_readoptions_set_fill_cache(
    xleveldb_readoptions_t*, unsigned char);
extern void xleveldb_readoptions_set_snapshot(
    xleveldb_readoptions_t*,
    const xleveldb_snapshot_t*);

/* Write options */

extern xleveldb_writeoptions_t* xleveldb_writeoptions_create();
extern void xleveldb_writeoptions_destroy(xleveldb_writeoptions_t*);
extern void xleveldb_writeoptions_set_sync(
    xleveldb_writeoptions_t*, unsigned char);

/* Cache */

extern xleveldb_cache_t* xleveldb_cache_create_lru(size_t capacity);
extern void xleveldb_cache_destroy(xleveldb_cache_t* cache);

/* Env */

extern xleveldb_env_t* xleveldb_create_default_env();
extern void xleveldb_env_destroy(xleveldb_env_t*);

/* Utility */

/* Calls free(ptr).
   REQUIRES: ptr was malloc()-ed and returned by one of the routines
   in this file.  Note that in certain cases (typically on Windows), you
   may need to call this routine instead of free(ptr) to dispose of
   malloc()-ed memory returned by this library. */
extern void xleveldb_free(void* ptr);

/* Return the major version number for this release. */
extern int xleveldb_major_version();

/* Return the minor version number for this release. */
extern int xleveldb_minor_version();

#ifdef __cplusplus
}  /* end extern "C" */
#endif

#endif  /* STORAGE_XLEVELDB_INCLUDE_C_H_ */
