// test.h (2013-06-19)
// Li Xinjie (xjason.li@gmail.com)

#include <xleveldb/db.h>
#include <vector>
#include <stdio.h>
#include <iostream>
#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>
#include <xleveldb/env.h>

using namespace std;
using namespace xleveldb;
using namespace boost;

DB* db = NULL;

void Put(const std::string& row, const std::string& col, const std::string& val, uint64_t seq, uint64_t ttl) {
  Status s = db->Put(WriteOptions(), Cell(row, col), val, &seq, ttl);
  if (!s.ok()) {
    printf("DB::Put(%s,%s): %s\n", row.c_str(), col.c_str(), s.ToString().c_str());
  } else {
    printf("DB::Put(%s,%s) OK, seq=%zd\n", row.c_str(), col.c_str(), seq);
  }
}

void Del(const std::string& row, const std::string& col) {
  uint64_t seq = 0;
  Status s = db->Delete(WriteOptions(), Cell(row, col), &seq);
  if (!s.ok()) {
    printf("DB::Put(%s,%s): %s\n", row.c_str(), col.c_str(), s.ToString().c_str());
  } else {
    printf("DB::Put(%s,%s) OK, seq=%zd\n", row.c_str(), col.c_str(), seq);
  }
}

void Get(const std::string& row, const std::string& col) {
  uint64_t seq = 0;
  uint64_t ttl = 0;
  string value;
  Status s = db->Get(ReadOptions(), Cell(row, col), &value, &seq, &ttl);
  if (!s.ok()) {
    printf("DB::Get(%s,%s): %s\n", row.c_str(), col.c_str(), s.ToString().c_str());
  } else {
    printf("DB::Get(%s,%s) OK, seq=%zd ttl=%zd val=%s\n", row.c_str(), col.c_str(),
        seq, ttl, value.c_str());
  }
}

void ParseCell(std::string& cell, std::string* key, std::string* col) {
  std::vector<std::string> fields;
  boost::split(fields, cell, boost::is_any_of("."));
  *key = fields[0];
  if (fields.size() > 1) {
    *col = fields[1];
  }
}

bool ExecuteLine(std::string& line) {
  boost::trim(line);
  if (line.empty()) {
    return true;
  }
  std::vector<std::string> fields;
  boost::split(fields, line, boost::is_any_of(" "));
  if (fields[0] == "exit" || fields[0] == "quit") {
    return false;
  }

  std::string row, col;
  if (fields[0] == "put" && fields.size() == 5) {
    ParseCell(fields[1], &row, &col);
    Put(row, col, fields[2], lexical_cast<uint64_t>(fields[3].c_str()), lexical_cast<uint64_t>(fields[4].c_str()));
  } else if (fields[0] == "get" && fields.size() == 2) {
    ParseCell(fields[1], &row, &col);
    Get(row, col);
  } else if (fields[0] == "del" && fields.size() == 2) {
    ParseCell(fields[1], &row, &col);
    Del(row, col);
  }
  return true;
}

int main() {
  Options opt;
  opt.create_if_missing = true;
  Status s = DB::Open(opt, "data", &db);
  if (!s.ok()) {
    printf("DB::Open: %s\n", s.ToString().c_str());
    return 1;
  }

  std::string line;
  while (true) {
    printf("[%zd] >> ", opt.env->NowMicros());
    getline(std::cin, line);
    if (!std::cin.good()) {
      cout << endl;
      break;
    }
    if (!ExecuteLine(line)) {
      break;
    }
  }
}
