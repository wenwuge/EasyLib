// test2.cc (2013-10-11)
// Li Xinjie (xjason.li@gmail.com)

#include <boost/lexical_cast.hpp>
#include <xleveldb/db.h>
#include <iostream>
#include <gflags/gflags.h>
#include <stdio.h>

using namespace xleveldb;
using namespace std;
using namespace boost;

DEFINE_int32(count, 10000, "");
DEFINE_int32(length, 100, "");
DEFINE_int32(seed, 0, "");
DEFINE_string(x, "put", "");

void RandStr(size_t len, std::string* s) {
    for (size_t i = 0; i < len; ++i) {
        char c = rand() % 26 + 97;
        s->append(1, c);
    }
}

void SeqStr(size_t len, std::string* s) {
    static uint32_t x = FLAGS_seed;
    char buf[32] = {};
    sprintf(buf, "key-%010u", x);
    *s = buf;
    ++x;
}

int main(int argc, char** argv) {
    google::ParseCommandLineFlags(&argc, &argv, false);
    Options opt;
    opt.create_if_missing = true;
    DB* db = NULL;
    Status s = DB::Open(opt, "data", &db);
    if (!s.ok()) {
        printf("DB::Open: %s\n", s.ToString().c_str());
        return 1;
    }

    size_t err = 0;
    if (FLAGS_x == "put") {
        for (int i = 0; i < FLAGS_count; ++i) {
            string key, val;
            RandStr(FLAGS_length, &key);
            val = key;
            uint64_t seq = 0;
            uint64_t ttl = 0;
            s = db->Put(WriteOptions(), Cell(key, ""), val, &seq, ttl);
            if (!s.ok()) {
                printf("DB::Put(%s): %s\n", key.c_str(), s.ToString().c_str());
                ++err;
            }
            if (i && i% 50000 == 0) {
                printf("%d ok\n", i);
            }
        }
    } else if (FLAGS_x == "get") {
        for (int i = 0; i < FLAGS_count; ++i) {
            string key;
            string value;
            RandStr(FLAGS_length, &key);
            uint64_t seq = 0;
            uint64_t ttl = 0;
            s = db->Get(ReadOptions(), Cell(key, ""), &value, &seq, &ttl);
            if (!s.ok()) {
                printf("DB::Get(%s): %s\n", key.c_str(), s.ToString().c_str());
                ++err;
            } else if (value != key) {
                printf("DB::Get(%s): invalid value\n", key.c_str());
                ++err;
            }
        }
    } else if (FLAGS_x == "iter") {
        size_t n = 0;
        DB::Iterator* iter = db->NewIterator(ReadOptions());
        iter->SeekToFirst();
        for (; iter->Valid(); iter->Next()) {
            n++;
            printf("%s\n", iter->cell().row.ToString().c_str());
        }
        printf("Total %zd\n", n);
    } else {
        printf("Invalid x\n");
    }
    printf("Total error = %zd\n", err);
}
