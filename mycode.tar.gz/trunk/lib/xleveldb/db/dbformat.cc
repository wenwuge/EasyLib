// Copyright (c) 2011 The LevelDB Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file. See the AUTHORS file for names of contributors.

#include <stdio.h>
#include "db/dbformat.h"
#include "port/port.h"
#include "util/coding.h"

namespace xleveldb {

uint64_t PackSequenceAndType(uint64_t seq, ValueType t) {
  assert(seq <= kMaxSequenceNumber);
  assert(t <= kValueTypeForSeek);
  return (seq << 8) | t;
}

void AppendInternalKey(std::string* result, const ParsedInternalKey& key) {
  AppendInternalCell(result, key.cell);
  PutFixed64(result, PackSequenceAndType(key.sequence, key.type));
}

void AppendInternalCell(std::string* result, const Cell& cell) {
  result->append(cell.row.data(), cell.row.size());
  PutLengthPostfixedSlice(result, cell.col);
}

std::string ParsedInternalKey::DebugString() const {
  char buf[50];
  snprintf(buf, sizeof(buf), "' @ %llu : %d",
           (unsigned long long) sequence,
           int(type));
  std::string result = "'";
  result += EscapeString(cell.row.ToString());
  result += ".";
  result += EscapeString(cell.col.ToString());
  result += buf;
  return result;
}

std::string InternalKey::DebugString() const {
  std::string result;
  ParsedInternalKey parsed;
  if (ParseInternalKey(rep_, &parsed)) {
    result = parsed.DebugString();
  } else {
    result = "(bad)";
    result.append(EscapeString(rep_));
  }
  return result;
}

const char* InternalKeyComparator::Name() const {
  return "leveldb.InternalKeyComparator";
}

int InternalKeyComparator::Compare(const Slice& akey, const Slice& bkey) const {
  // Order by:
  //    increasing user key (according to user-supplied comparator)
  //    increasing column
  //    decreasing sequence number
  //    decreasing type (though sequence# should be enough to disambiguate)
  Cell ca = ExtractCell(akey);
  Cell cb = ExtractCell(bkey);
  int r = CompareCell(ca, cb);
  if (r == 0) {
    const uint64_t anum = DecodeFixed64(akey.data() + akey.size() - 8);
    const uint64_t bnum = DecodeFixed64(bkey.data() + bkey.size() - 8);
    if (anum > bnum) {
      r = -1;
    } else if (anum < bnum) {
      r = +1;
    }
  }
  return r;
}

void InternalKeyComparator::FindShortestSeparator(
      std::string* start,
      const Slice& limit) const {
  // Attempt to shorten the user portion of the key
  Cell cstart, climit;
  ExtractCell(*start, &cstart);
  ExtractCell(limit, &climit);
  std::string tmp(cstart.row.data(), cstart.row.size());
  row_comparator()->FindShortestSeparator(&tmp, climit.row);
  if (tmp.size() < cstart.row.size() &&
      row_comparator()->Compare(cstart.row, tmp) < 0) {
    // User key has become shorter physically, but larger logically.
    // Tack on the earliest possible number to the shortened user key.
    PutLengthPostfixedSlice(&tmp, Slice());
    PutFixed64(&tmp, PackSequenceAndType(kMaxSequenceNumber,kValueTypeForSeek));
    assert(this->Compare(*start, tmp) < 0);
    assert(this->Compare(tmp, limit) < 0);
    start->swap(tmp);
    return;
  }
  tmp.assign(cstart.col.data(), cstart.col.size());
  col_comparator()->FindShortestSeparator(&tmp, climit.col);
  if (tmp.size() < cstart.col.size() &&
      col_comparator()->Compare(cstart.col, tmp) < 0) {
    // User col has become shorter physically, but larger logically.
    // Tack on the earliest possible number to the shortened user column.
    tmp.insert(0, cstart.row.data(), cstart.row.size());
    PutFixed64(&tmp, PackSequenceAndType(kMaxSequenceNumber,kValueTypeForSeek));
    assert(this->Compare(*start, tmp) < 0);
    assert(this->Compare(tmp, limit) < 0);
    start->swap(tmp);
    return;
  }
}

void InternalKeyComparator::FindShortSuccessor(std::string* key) const {
  Cell c = ExtractCell(*key);
  std::string tmp(c.row.data(), c.row.size());
  row_comparator()->FindShortSuccessor(&tmp);
  if (tmp.size() < c.row.size() &&
      row_comparator()->Compare(c.row, tmp) < 0) {
    // User key has become shorter physically, but larger logically.
    // Tack on the earliest possible number to the shortened user key.
    PutLengthPostfixedSlice(&tmp, Slice());
    PutFixed64(&tmp, PackSequenceAndType(kMaxSequenceNumber,kValueTypeForSeek));
    assert(this->Compare(*key, tmp) < 0);
    key->swap(tmp);
    return;
  }
  tmp.assign(c.col.data(), c.col.size());
  col_comparator()->FindShortSuccessor(&tmp);
  if (tmp.size() < c.col.size() &&
      col_comparator()->Compare(c.col, tmp) < 0) {
    // User col has become shorter physically, but larger logically.
    // Tack on the earliest possible number to the shortened user key.
    tmp.insert(0, c.row.data(), c.row.size());
    PutFixed64(&tmp, PackSequenceAndType(kMaxSequenceNumber,kValueTypeForSeek));
    assert(this->Compare(*key, tmp) < 0);
    key->swap(tmp);
    return;
  }
}

const char* InternalFilterPolicy::Name() const {
  return user_policy_->Name();
}

void InternalFilterPolicy::CreateFilter(const Slice* keys, int n,
                                        std::string* dst) const {
  // We rely on the fact that the code in table.cc does not mind us
  // adjusting keys[].
  Slice* mkey = const_cast<Slice*>(keys);
  for (int i = 0; i < n; i++) {
    mkey[i] = ExtractInternalCell(keys[i]);
    // TODO(sanjay): Suppress dups?
  }
  user_policy_->CreateFilter(keys, n, dst);
}

bool InternalFilterPolicy::KeyMayMatch(const Slice& key, const Slice& f) const {
  return user_policy_->KeyMayMatch(ExtractInternalCell(key), f);
}

LookupKey::LookupKey(const Cell& cell, SequenceNumber s) {
  size_t csize = CellLength(cell);
  size_t needed = csize + 13;  // A conservative estimate
  char* dst;
  if (needed <= sizeof(space_)) {
    dst = space_;
  } else {
    dst = new char[needed];
  }
  start_ = dst;
  dst = EncodeVarint32(dst, csize + 8);
  kstart_ = dst;
  memcpy(dst, cell.row.data(), cell.row.size());
  dst += cell.row.size();
  memcpy(dst, cell.col.data(), cell.col.size());
  dst += cell.col.size();
  dst = EncodeReversedVarint32(dst, cell.col.size());
  EncodeFixed64(dst, PackSequenceAndType(s, kValueTypeForSeek));
  dst += 8;
  end_ = dst;
}

}  // namespace xleveldb
