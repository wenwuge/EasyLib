// Copyright (c) 2011 The LevelDB Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file. See the AUTHORS file for names of contributors.

#include "xleveldb/c.h"

#include <stdlib.h>
#include <unistd.h>
#include "xleveldb/cache.h"
#include "xleveldb/comparator.h"
#include "xleveldb/db.h"
#include "xleveldb/env.h"
#include "xleveldb/filter_policy.h"
#include "xleveldb/iterator.h"
#include "xleveldb/options.h"
#include "xleveldb/status.h"
#include "xleveldb/write_batch.h"
#include "xleveldb/cell.h"

using xleveldb::Cache;
using xleveldb::Comparator;
using xleveldb::CompressionType;
using xleveldb::DB;
using xleveldb::Env;
using xleveldb::FileLock;
using xleveldb::FilterPolicy;
using xleveldb::Iterator;
using xleveldb::kMajorVersion;
using xleveldb::kMinorVersion;
using xleveldb::Logger;
using xleveldb::NewBloomFilterPolicy;
using xleveldb::NewLRUCache;
using xleveldb::Options;
using xleveldb::RandomAccessFile;
using xleveldb::Range;
using xleveldb::ReadOptions;
using xleveldb::SequentialFile;
using xleveldb::Slice;
using xleveldb::Snapshot;
using xleveldb::Status;
using xleveldb::WritableFile;
using xleveldb::WriteBatch;
using xleveldb::WriteOptions;
using xleveldb::Cell;

extern "C" {

struct xleveldb_t              { DB*               rep; };
struct xleveldb_db_iterator_t  { DB::Iterator*     rep; };
struct xleveldb_iterator_t     { Iterator*         rep; };
struct xleveldb_writebatch_t   { WriteBatch        rep; };
struct xleveldb_snapshot_t     { const Snapshot*   rep; };
struct xleveldb_readoptions_t  { ReadOptions       rep; };
struct xleveldb_writeoptions_t { WriteOptions      rep; };
struct xleveldb_options_t      { Options           rep; };
struct xleveldb_cache_t        { Cache*            rep; };
struct xleveldb_seqfile_t      { SequentialFile*   rep; };
struct xleveldb_randomfile_t   { RandomAccessFile* rep; };
struct xleveldb_writablefile_t { WritableFile*     rep; };
struct xleveldb_logger_t       { Logger*           rep; };
struct xleveldb_filelock_t     { FileLock*         rep; };

struct xleveldb_comparator_t : public Comparator {
  void* state_;
  void (*destructor_)(void*);
  int (*compare_)(
      void*,
      const char* a, size_t alen,
      const char* b, size_t blen);
  const char* (*name_)(void*);

  virtual ~xleveldb_comparator_t() {
    (*destructor_)(state_);
  }

  virtual int Compare(const Slice& a, const Slice& b) const {
    return (*compare_)(state_, a.data(), a.size(), b.data(), b.size());
  }

  virtual const char* Name() const {
    return (*name_)(state_);
  }

  // No-ops since the C binding does not support key shortening methods.
  virtual void FindShortestSeparator(std::string*, const Slice&) const { }
  virtual void FindShortSuccessor(std::string* key) const { }
};

struct xleveldb_filterpolicy_t : public FilterPolicy {
  void* state_;
  void (*destructor_)(void*);
  const char* (*name_)(void*);
  char* (*create_)(
      void*,
      const char* const* key_array, const size_t* key_length_array,
      int num_keys,
      size_t* filter_length);
  unsigned char (*key_match_)(
      void*,
      const char* key, size_t length,
      const char* filter, size_t filter_length);

  virtual ~xleveldb_filterpolicy_t() {
    (*destructor_)(state_);
  }

  virtual const char* Name() const {
    return (*name_)(state_);
  }

  virtual void CreateFilter(const Slice* keys, int n, std::string* dst) const {
    std::vector<const char*> key_pointers(n);
    std::vector<size_t> key_sizes(n);
    for (int i = 0; i < n; i++) {
      key_pointers[i] = keys[i].data();
      key_sizes[i] = keys[i].size();
    }
    size_t len;
    char* filter = (*create_)(state_, &key_pointers[0], &key_sizes[0], n, &len);
    dst->append(filter, len);
    free(filter);
  }

  virtual bool KeyMayMatch(const Slice& key, const Slice& filter) const {
    return (*key_match_)(state_, key.data(), key.size(),
                         filter.data(), filter.size());
  }
};

struct xleveldb_env_t {
  Env* rep;
  bool is_default;
};

static bool SaveError(char** errptr, const Status& s) {
  assert(errptr != NULL);
  if (s.ok()) {
    return false;
  } else if (*errptr == NULL) {
    *errptr = strdup(s.ToString().c_str());
  } else {
    // TODO(sanjay): Merge with existing error?
    free(*errptr);
    *errptr = strdup(s.ToString().c_str());
  }
  return true;
}

static char* CopyString(const std::string& str) {
  char* result = reinterpret_cast<char*>(malloc(sizeof(char) * str.size()));
  memcpy(result, str.data(), sizeof(char) * str.size());
  return result;
}

xleveldb_t* xleveldb_open(
    const xleveldb_options_t* options,
    const char* name,
    char** errptr) {
  DB* db;
  if (SaveError(errptr, DB::Open(options->rep, std::string(name), &db))) {
    return NULL;
  }
  xleveldb_t* result = new xleveldb_t;
  result->rep = db;
  return result;
}

void xleveldb_close(xleveldb_t* db) {
  delete db->rep;
  delete db;
}

void xleveldb_put(
    xleveldb_t* db,
    const xleveldb_writeoptions_t* options,
    const char* key, size_t keylen,
    const char* col, size_t collen,
    const char* val, size_t vallen,
    uint64_t* seq, uint64_t ttl,
    char** errptr) {
  SaveError(errptr,
            db->rep->Put(options->rep,
              Cell(Slice(key, keylen), Slice(col, collen)),
              Slice(val, vallen), seq, ttl));
}

void xleveldb_delete(
    xleveldb_t* db,
    const xleveldb_writeoptions_t* options,
    const char* key, size_t keylen,
    const char* col, size_t collen,
    uint64_t* seq,
    char** errptr) {
  SaveError(errptr, db->rep->Delete(options->rep,
        Cell(Slice(key, keylen), Slice(col, collen)), seq));
}


void xleveldb_write(
    xleveldb_t* db,
    const xleveldb_writeoptions_t* options,
    xleveldb_writebatch_t* batch,
    char** errptr) {
  SaveError(errptr, db->rep->Write(options->rep, &batch->rep));
}

char* xleveldb_get(
    xleveldb_t* db,
    const xleveldb_readoptions_t* options,
    const char* key, size_t keylen,
    const char* col, size_t collen,
    size_t* vallen,
    uint64_t* seq, 
    uint64_t* ttl,
    char** errptr) {
  char* result = NULL;
  std::string tmp;
  Status s = db->rep->Get(options->rep, Cell(Slice(key, keylen), Slice(col, collen)), &tmp, seq, ttl);
  if (s.ok()) {
    *vallen = tmp.size();
    result = CopyString(tmp);
  } else {
    *vallen = 0;
    if (!s.IsNotFound()) {
      SaveError(errptr, s);
    }
  }
  return result;
}

xleveldb_db_iterator_t* xleveldb_create_iterator(
    xleveldb_t* db,
    const xleveldb_readoptions_t* options) {
  xleveldb_db_iterator_t* result = new xleveldb_db_iterator_t;
  result->rep = db->rep->NewIterator(options->rep);
  return result;
}

const xleveldb_snapshot_t* xleveldb_create_snapshot(
    xleveldb_t* db) {
  xleveldb_snapshot_t* result = new xleveldb_snapshot_t;
  result->rep = db->rep->GetSnapshot();
  return result;
}

void xleveldb_release_snapshot(
    xleveldb_t* db,
    const xleveldb_snapshot_t* snapshot) {
  db->rep->ReleaseSnapshot(snapshot->rep);
  delete snapshot;
}

char* xleveldb_property_value(
    xleveldb_t* db,
    const char* propname) {
  std::string tmp;
  if (db->rep->GetProperty(Slice(propname), &tmp)) {
    // We use strdup() since we expect human readable output.
    return strdup(tmp.c_str());
  } else {
    return NULL;
  }
}

void xleveldb_approximate_sizes(
    xleveldb_t* db,
    int num_ranges,
    const char* const* range_start_key, const size_t* range_start_key_len,
    const char* const* range_limit_key, const size_t* range_limit_key_len,
    uint64_t* sizes) {
  Range* ranges = new Range[num_ranges];
  for (int i = 0; i < num_ranges; i++) {
    ranges[i].start = Slice(range_start_key[i], range_start_key_len[i]);
    ranges[i].limit = Slice(range_limit_key[i], range_limit_key_len[i]);
  }
  db->rep->GetApproximateSizes(ranges, num_ranges, sizes);
  delete[] ranges;
}

void xleveldb_compact_range(
    xleveldb_t* db,
    const char* start_key, size_t start_key_len,
    const char* start_col, size_t start_col_len,
    const char* limit_key, size_t limit_key_len,
    const char* limit_col, size_t limit_col_len) {
  Cell a, b;
  db->rep->CompactRange(
      // Pass NULL Slice if corresponding "const char*" is NULL
      (start_key ? (a = Cell(Slice(start_key, start_key_len), Slice(start_col, start_col_len)), &a) : NULL),
      (limit_key ? (b = Cell(Slice(limit_key, limit_key_len), Slice(limit_col, limit_col_len)), &b) : NULL));
}

void xleveldb_destroy_db(
    const xleveldb_options_t* options,
    const char* name,
    char** errptr) {
  SaveError(errptr, DestroyDB(name, options->rep));
}

void xleveldb_repair_db(
    const xleveldb_options_t* options,
    const char* name,
    char** errptr) {
  SaveError(errptr, RepairDB(name, options->rep));
}

void xleveldb_iter_destroy(xleveldb_iterator_t* iter) {
  delete iter->rep;
  delete iter;
}

unsigned char xleveldb_iter_valid(const xleveldb_iterator_t* iter) {
  return iter->rep->Valid();
}

void xleveldb_iter_seek_to_first(xleveldb_iterator_t* iter) {
  iter->rep->SeekToFirst();
}

void xleveldb_iter_seek_to_last(xleveldb_iterator_t* iter) {
  iter->rep->SeekToLast();
}

void xleveldb_iter_seek(xleveldb_iterator_t* iter, const char* k, size_t klen) {
  iter->rep->Seek(Slice(k, klen));
}

void xleveldb_iter_next(xleveldb_iterator_t* iter) {
  iter->rep->Next();
}

void xleveldb_iter_prev(xleveldb_iterator_t* iter) {
  iter->rep->Prev();
}

const char* xleveldb_iter_key(const xleveldb_iterator_t* iter, size_t* klen) {
  Slice s = iter->rep->key();
  *klen = s.size();
  return s.data();
}

uint64_t xleveldb_iter_flag(const xleveldb_iterator_t* iter) {
  return iter->rep->flag();
}

const char* xleveldb_iter_value(const xleveldb_iterator_t* iter, size_t* vlen) {
  Slice s = iter->rep->value();
  *vlen = s.size();
  return s.data();
}

void xleveldb_iter_get_error(const xleveldb_iterator_t* iter, char** errptr) {
  SaveError(errptr, iter->rep->status());
}



void xleveldb_db_iter_destroy(xleveldb_db_iterator_t* iter) {
  delete iter->rep;
  delete iter;
}

unsigned char xleveldb_db_iter_valid(const xleveldb_db_iterator_t* iter) {
  return iter->rep->Valid();
}

void xleveldb_db_iter_seek_to_first(xleveldb_db_iterator_t* iter) {
  iter->rep->SeekToFirst();
}

void xleveldb_db_iter_seek_to_last(xleveldb_db_iterator_t* iter) {
  iter->rep->SeekToLast();
}

void xleveldb_db_iter_seek(xleveldb_db_iterator_t* iter, const char* k, size_t klen) {
  iter->rep->Seek(Slice(k, klen));
}

void xleveldb_db_iter_next(xleveldb_db_iterator_t* iter) {
  iter->rep->Next();
}

void xleveldb_db_iter_prev(xleveldb_db_iterator_t* iter) {
  iter->rep->Prev();
}

const char* xleveldb_db_iter_row(const xleveldb_db_iterator_t* iter, size_t* rlen) {
  Slice s = iter->rep->cell().row;
  *rlen = s.size();
  return s.data();
}

const char* xleveldb_db_iter_key(const xleveldb_db_iterator_t* iter, size_t* clen) {
  Slice s = iter->rep->cell().col;
  *clen = s.size();
  return s.data();
}

uint64_t xleveldb_db_iter_ttl(const xleveldb_db_iterator_t* iter) {
  return iter->rep->ttl();
}

const char* xleveldb_db_iter_value(const xleveldb_db_iterator_t* iter, size_t* vlen) {
  Slice s = iter->rep->value();
  *vlen = s.size();
  return s.data();
}

void xleveldb_db_iter_get_error(const xleveldb_db_iterator_t* iter, char** errptr) {
  SaveError(errptr, iter->rep->status());
}




xleveldb_writebatch_t* xleveldb_writebatch_create() {
  return new xleveldb_writebatch_t;
}

void xleveldb_writebatch_destroy(xleveldb_writebatch_t* b) {
  delete b;
}

void xleveldb_writebatch_clear(xleveldb_writebatch_t* b) {
  b->rep.Clear();
}

void xleveldb_writebatch_put(
    xleveldb_writebatch_t* b,
    const char* key, size_t klen,
    const char* col, size_t clen,
    const char* val, size_t vlen,
    uint64_t ttl) {
  b->rep.Put(Cell(Slice(key, klen), Slice(col, clen)), Slice(val, vlen), ttl);
}

void xleveldb_writebatch_delete(
    xleveldb_writebatch_t* b,
    const char* key, size_t klen,
    const char* col, size_t clen) {
  b->rep.Delete(Cell(Slice(key, klen), Slice(col, clen)));
}

void xleveldb_writebatch_iterate(
    xleveldb_writebatch_t* b,
    void* state,
    void (*put)(void*, const char* k, size_t klen, const char* c, size_t clen, const char* v, size_t vlen, uint64_t ttl),
    void (*deleted)(void*, const char* k, size_t klen, const char* c, size_t clen)) {
  class H : public WriteBatch::Handler {
   public:
    void* state_;
    void (*put_)(void*, const char* k, size_t klen, const char* c, size_t clen, const char* v, size_t vlen, uint64_t ttl);
    void (*deleted_)(void*, const char* k, size_t klen, const char* c, size_t clen);
    virtual void Put(const Cell& cell, const Slice& value, uint64_t ttl) {
      (*put_)(state_, cell.row.data(), cell.row.size(), cell.col.data(), cell.col.size(), value.data(), value.size(), ttl);
    }
    virtual void Delete(const Cell& cell) {
      (*deleted_)(state_, cell.row.data(), cell.row.size(), cell.col.data(), cell.col.size());
    }
  };
  H handler;
  handler.state_ = state;
  handler.put_ = put;
  handler.deleted_ = deleted;
  b->rep.Iterate(&handler);
}

xleveldb_options_t* xleveldb_options_create() {
  return new xleveldb_options_t;
}

void xleveldb_options_destroy(xleveldb_options_t* options) {
  delete options;
}

void xleveldb_options_set_row_comparator(
    xleveldb_options_t* opt,
    xleveldb_comparator_t* cmp) {
  opt->rep.row_comparator = cmp;
}

void xleveldb_options_set_col_comparator(
    xleveldb_options_t* opt,
    xleveldb_comparator_t* cmp) {
  opt->rep.col_comparator = cmp;
}

void xleveldb_options_set_filter_policy(
    xleveldb_options_t* opt,
    xleveldb_filterpolicy_t* policy) {
  opt->rep.filter_policy = policy;
}

void xleveldb_options_set_create_if_missing(
    xleveldb_options_t* opt, unsigned char v) {
  opt->rep.create_if_missing = v;
}

void xleveldb_options_set_error_if_exists(
    xleveldb_options_t* opt, unsigned char v) {
  opt->rep.error_if_exists = v;
}

void xleveldb_options_set_paranoid_checks(
    xleveldb_options_t* opt, unsigned char v) {
  opt->rep.paranoid_checks = v;
}

void xleveldb_options_set_env(xleveldb_options_t* opt, xleveldb_env_t* env) {
  opt->rep.env = (env ? env->rep : NULL);
}

void xleveldb_options_set_info_log(xleveldb_options_t* opt, xleveldb_logger_t* l) {
  opt->rep.info_log = (l ? l->rep : NULL);
}

void xleveldb_options_set_write_buffer_size(xleveldb_options_t* opt, size_t s) {
  opt->rep.write_buffer_size = s;
}

void xleveldb_options_set_max_open_files(xleveldb_options_t* opt, int n) {
  opt->rep.max_open_files = n;
}

void xleveldb_options_set_cache(xleveldb_options_t* opt, xleveldb_cache_t* c) {
  opt->rep.block_cache = c->rep;
}

void xleveldb_options_set_block_size(xleveldb_options_t* opt, size_t s) {
  opt->rep.block_size = s;
}

void xleveldb_options_set_block_restart_interval(xleveldb_options_t* opt, int n) {
  opt->rep.block_restart_interval = n;
}

void xleveldb_options_set_compression(xleveldb_options_t* opt, int t) {
  opt->rep.compression = static_cast<CompressionType>(t);
}

xleveldb_comparator_t* xleveldb_comparator_create(
    void* state,
    void (*destructor)(void*),
    int (*compare)(
        void*,
        const char* a, size_t alen,
        const char* b, size_t blen),
    const char* (*name)(void*)) {
  xleveldb_comparator_t* result = new xleveldb_comparator_t;
  result->state_ = state;
  result->destructor_ = destructor;
  result->compare_ = compare;
  result->name_ = name;
  return result;
}

void xleveldb_comparator_destroy(xleveldb_comparator_t* cmp) {
  delete cmp;
}

xleveldb_filterpolicy_t* xleveldb_filterpolicy_create(
    void* state,
    void (*destructor)(void*),
    char* (*create_filter)(
        void*,
        const char* const* key_array, const size_t* key_length_array,
        int num_keys,
        size_t* filter_length),
    unsigned char (*key_may_match)(
        void*,
        const char* key, size_t length,
        const char* filter, size_t filter_length),
    const char* (*name)(void*)) {
  xleveldb_filterpolicy_t* result = new xleveldb_filterpolicy_t;
  result->state_ = state;
  result->destructor_ = destructor;
  result->create_ = create_filter;
  result->key_match_ = key_may_match;
  result->name_ = name;
  return result;
}

void xleveldb_filterpolicy_destroy(xleveldb_filterpolicy_t* filter) {
  delete filter;
}

xleveldb_filterpolicy_t* xleveldb_filterpolicy_create_bloom(int bits_per_key) {
  // Make a xleveldb_filterpolicy_t, but override all of its methods so
  // they delegate to a NewBloomFilterPolicy() instead of user
  // supplied C functions.
  struct Wrapper : public xleveldb_filterpolicy_t {
    const FilterPolicy* rep_;
    ~Wrapper() { delete rep_; }
    const char* Name() const { return rep_->Name(); }
    void CreateFilter(const Slice* keys, int n, std::string* dst) const {
      return rep_->CreateFilter(keys, n, dst);
    }
    bool KeyMayMatch(const Slice& key, const Slice& filter) const {
      return rep_->KeyMayMatch(key, filter);
    }
    static void DoNothing(void*) { }
  };
  Wrapper* wrapper = new Wrapper;
  wrapper->rep_ = NewBloomFilterPolicy(bits_per_key);
  wrapper->state_ = NULL;
  wrapper->destructor_ = &Wrapper::DoNothing;
  return wrapper;
}

xleveldb_readoptions_t* xleveldb_readoptions_create() {
  return new xleveldb_readoptions_t;
}

void xleveldb_readoptions_destroy(xleveldb_readoptions_t* opt) {
  delete opt;
}

void xleveldb_readoptions_set_verify_checksums(
    xleveldb_readoptions_t* opt,
    unsigned char v) {
  opt->rep.verify_checksums = v;
}

void xleveldb_readoptions_set_fill_cache(
    xleveldb_readoptions_t* opt, unsigned char v) {
  opt->rep.fill_cache = v;
}

void xleveldb_readoptions_set_snapshot(
    xleveldb_readoptions_t* opt,
    const xleveldb_snapshot_t* snap) {
  opt->rep.snapshot = (snap ? snap->rep : NULL);
}

xleveldb_writeoptions_t* xleveldb_writeoptions_create() {
  return new xleveldb_writeoptions_t;
}

void xleveldb_writeoptions_destroy(xleveldb_writeoptions_t* opt) {
  delete opt;
}

void xleveldb_writeoptions_set_sync(
    xleveldb_writeoptions_t* opt, unsigned char v) {
  opt->rep.sync = v;
}

xleveldb_cache_t* xleveldb_cache_create_lru(size_t capacity) {
  xleveldb_cache_t* c = new xleveldb_cache_t;
  c->rep = NewLRUCache(capacity);
  return c;
}

void xleveldb_cache_destroy(xleveldb_cache_t* cache) {
  delete cache->rep;
  delete cache;
}

xleveldb_env_t* xleveldb_create_default_env() {
  xleveldb_env_t* result = new xleveldb_env_t;
  result->rep = Env::Default();
  result->is_default = true;
  return result;
}

void xleveldb_env_destroy(xleveldb_env_t* env) {
  if (!env->is_default) delete env->rep;
  delete env;
}

void xleveldb_free(void* ptr) {
  free(ptr);
}

int xleveldb_major_version() {
  return kMajorVersion;
}

int xleveldb_minor_version() {
  return kMinorVersion;
}

}  // end extern "C"
