/*
 * =============================================================================
 *
 *       Filename:  lock.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  04/01/2012 00:02:51
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Xinjie Li (jasonli), xjason.li@gmail.com
 *        Company:  Qihoo inc.
 *
 * =============================================================================
 */

#ifndef ZOOKEEPER_LOCK_H_
#define ZOOKEEPER_LOCK_H_


#endif // ZOOKEEPER_LOCK_H_
