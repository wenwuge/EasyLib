/*
 * =============================================================================
 *
 *       Filename:  function_watcher.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  03/31/2012 13:22:58
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Xinjie Li (jasonli), xjason.li@gmail.com
 *        Company:  Qihoo inc.
 *
 * =============================================================================
 */

#ifndef ZOOKEEPER_FUNCTION_WATCHER_H_
#define ZOOKEEPER_FUNCTION_WATCHER_H_

#include <boost/function.hpp>
#include "watcher.h"

ZOOKEEPER_BEGIN

class FunctionWatcher : public Watcher {
public:
    FunctionWatcher(
            const boost::function<void(const WatchedEvent&)> &function)
        : function_(function) {}

    virtual void Process(const WatchedEvent &event) {
        function_(event);
    }

private:
    boost::function<void(const WatchedEvent&)> function_;
};

ZOOKEEPER_END

#endif // ZOOKEEPER_FUNCTION_WATCHER_H_
