/*
 * =============================================================================
 *
 *       Filename:  session_manager.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  03/28/2012 14:16:51
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Xinjie Li (jasonli), xjason.li@gmail.com
 *        Company:  Qihoo inc.
 *
 * =============================================================================
 */

#ifndef ZOOKEEPER_SESSION_MANAGER_H_
#define ZOOKEEPER_SESSION_MANAGER_H_

#include "../zk/zookeeper.h"
#include "../zk/watcher.h"

ZOOKEEPER_BEGIN

class SyncPrimitive;

class SessionManager : public Watcher {
public:
    SessionManager();
    ~SessionManager();

    bool Init(const std::string &hosts, int timeout);
private:
    bool InitZooKeeper();

    std::string hosts_;
    int timeout_;
};

ZOOKEEPER_END

#endif // ZOOKEEPER_SESSION_MANAGER_H_
