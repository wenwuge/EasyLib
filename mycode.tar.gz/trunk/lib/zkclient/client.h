/*
 * =============================================================================
 *
 *       Filename:  client.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  04/01/2012 18:07:25
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Xinjie Li (jasonli), xjason.li@gmail.com
 *        Company:  Qihoo inc.
 *
 * =============================================================================
 */

#ifndef ZOOKEEPER_CLIENT_H_
#define ZOOKEEPER_CLIENT_H_

#include <boost/thread.hpp>
#include "zk/watcher.h"

ZOOKEEPER_BEGIN

class ZooKeeper;

class Client : public Watcher {
public:
    Client(const std::string &hosts, int timeout);

    bool Init();
    void Close();

private:
};

ZOOKEEPER_END

#endif // ZOOKEEPER_CLIENT_H_
