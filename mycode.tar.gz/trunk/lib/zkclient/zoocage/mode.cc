#include "mode.h"

namespace zoocage {
namespace mode {

const char* ToString(Type mode) {
    switch (mode) {
    case kPersistent:
        return "Persistent";
    case kEphemeral:
        return "Ephemeral";
    case kPersistentSequence:
        return "PersistentSequence";
    case kEphemeralSequence:
        return "EphemeralSequence";
    default:
        return "Unknown";
    }
}
} // namespace mode
} // namespace zoocage
