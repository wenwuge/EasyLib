#ifndef ZOOCAGE_RESULTS_H_
#define ZOOCAGE_RESULTS_H_

#include <string>
#include <vector>
#include <boost/ptr_container/ptr_vector.hpp>
#include "op.h"
#include "acl.h"
#include "stat.h"
#include "status.h"

namespace zoocage {

struct CreateResult {
    virtual ~CreateResult() {}
    virtual const Status& status() const = 0;
    virtual const std::string& path() const = 0;
    virtual const std::string& path_created() const = 0;
};

struct DeleteResult {
    virtual ~DeleteResult() {}
    virtual const Status& status() const = 0;
    virtual const std::string& path() const = 0;
};

struct ExistsResult {
    virtual ~ExistsResult() {}
    virtual const Status& status() const = 0;
    virtual const std::string& path() const = 0;
    virtual const Stat& stat() const = 0;
};

struct GetResult {
    virtual ~GetResult() {}
    virtual const Status& status() const = 0;
    virtual const std::string& path() const = 0;
    virtual const std::string& data() const = 0;
    virtual const Stat& stat() const = 0;
};

struct SetResult {
    virtual ~SetResult() {}
    virtual const Status& status() const = 0;
    virtual const std::string& path() const = 0;
    virtual const Stat& stat() const = 0;
};

struct GetAclResult {
    virtual ~GetAclResult() {}
    virtual const Status& status() const = 0;
    virtual const std::string& path() const = 0;
    virtual const std::vector<Acl>& acls() const = 0;
    virtual const Stat& stat() const = 0;
};

struct SetAclResult {
    virtual ~SetAclResult() {}
    virtual const Status& status() const = 0;
    virtual const std::string& path() const = 0;
};

struct GetChildrenResult {
    virtual ~GetChildrenResult() {}
    virtual const Status& status() const = 0;
    virtual const std::string& path() const = 0;
    virtual const std::vector<std::string>& children() const = 0;
};

struct GetChildrenWithStatResult {
    virtual ~GetChildrenWithStatResult() {}
    virtual const Status& status() const = 0;
    virtual const std::string& path() const = 0;
    virtual const std::vector<std::string>& children() const = 0;
    virtual const Stat& stat() const = 0;
};

struct AddAuthResult {
    virtual ~AddAuthResult() {}
    virtual const Status& status() const = 0;
    virtual const std::string& scheme() const = 0;
    virtual const std::string& cert() const = 0;
};

struct MultiResult {
    virtual ~MultiResult() {}
    virtual const Status& status() const = 0;
    virtual const boost::ptr_vector<Op::Result>& results() const = 0;
};

} // namespace zoocage

#endif // ZOOCAGE_RESULTS_H_
