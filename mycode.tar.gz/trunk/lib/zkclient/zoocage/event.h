#ifndef ZKCLI_EVENT_H_
#define ZKCLI_EVENT_H_

#include <zookeeper/zookeeper.h>

namespace zoocage {

class Event {
public:
    static const int kNodeCreated = 1;
    static const int kNodeDeleted = 2;
    static const int kNodeChanged = 3;
    static const int kChildChanged = 4;
    static const int kSession = -1;
    static const int kNotWatching = -2;

    Event(int event) : type_(event) {}
    Event& operator = (int event) { type_ = event; return *this; }
    bool operator == (int event) const { return type_ == event; }
    bool operator != (int event) const { return type_ != event; }
    bool operator == (const Event &rhs) const { return type_ == rhs.type(); }
    bool operator != (const Event &rhs) const { return type_ != rhs.type(); }

    int type() const { return type_; }
    const char *ToString() const;

    bool IsNodeCreated() const { return type_ == kNodeCreated; }
    bool IsNodeDeleted() const { return type_ == kNodeDeleted; }
    bool IsNodeChanged() const { return type_ == kNodeChanged; }
    bool IsChildChanged() const { return type_ == kChildChanged; }
    bool IsSession() const { return type_ == kSession; }
    bool IsNotWatching() const { return type_ == kNotWatching; }

private:
    int type_;
};

} // namespace zoocage

#endif // ZKCLI_EVENT_H_
