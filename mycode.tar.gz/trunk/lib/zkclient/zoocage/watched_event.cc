/*
 * =============================================================================
 *
 *       Filename:  watched_event.cc
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  03/26/2012 18:26:41
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Xinjie Li (jasonli), xjason.li@gmail.com
 *        Company:  Qihoo inc.
 *
 * =============================================================================
 */

#include "watched_event.h"

namespace zoocage {

WatchedEvent::WatchedEvent(const Event& event, const State &state,
        const std::string& path)
    : event_(event)
    , state_(state)
    , path_(path)
{
}

std::string WatchedEvent::ToString() const {
    std::string msg = "WatchedEvent ";
    msg += " event:";
    msg += event_.ToString();
    msg += " state:";
    msg += state_.ToString();
    msg += " path:";
    msg += path_;
    return msg;
}

} // namespace zoocage
