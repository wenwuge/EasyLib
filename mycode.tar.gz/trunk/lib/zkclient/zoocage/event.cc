#include "event.h"

namespace zoocage {

const char *Event::ToString() const {
    if (type_ == 0) {
        return "ZOO_ERROR_EVENT";
    } else if (type_ == kNodeCreated) {
        return "ZOO_CREATED_EVENT";
    } else if (type_ == kNodeDeleted) {
        return "ZOO_DELETED_EVENT";
    } else if (type_ == kNodeChanged) {
        return "ZOO_CHANGED_EVENT";
    } else if (type_ == kChildChanged) {
        return "ZOO_CHILD_EVENT";
    } else if (type_ == kSession) {
        return "ZOO_SESSION_EVENT";
    } else if (type_ == kNotWatching) {
        return "ZOO_NOTWATCHING_EVENT";
    }
    return "INVALID_EVENT";
}

} // namespace zoocage
