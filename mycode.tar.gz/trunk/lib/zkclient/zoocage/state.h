/*
 * =============================================================================
 *
 *       Filename:  state.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  04/01/2012 15:21:01
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Xinjie Li (jasonli), xjason.li@gmail.com
 *        Company:  Qihoo inc.
 *
 * =============================================================================
 */

#ifndef ZKCLI_STATE_H_
#define ZKCLI_STATE_H_

#include <zookeeper/zookeeper.h>

namespace zoocage {

class State {
public:
    static const int kClosed = 0;
    static const int kConnecting = 1;
    static const int kAssociating = 2;
    static const int kConnected = 3;
    static const int kSessionExpired = -112;
    static const int kAuthFailed = -113;

    State(int state) : type_(state) {}
    State& operator = (int state) { type_ = state; return *this; }
    bool operator == (int state) const { return type_ == state; }
    bool operator != (int state) const { return type_ != state; }
    bool operator == (const State &rhs) const { return type_ == rhs.type(); }
    bool operator != (const State &rhs) const { return type_ != rhs.type(); }

    int type() const { return type_; }
    const char *ToString() const;

    bool IsClosed() const { return type_ == kClosed; }
    bool IsConnecting() const { return type_ == kConnecting; }
    bool IsAssociating() const { return type_ == kAssociating; }
    bool IsConnected() const { return type_ == kConnected; }
    bool IsSessionExpired() const { return type_ == kSessionExpired; }
    bool IsAuthFailed() const { return type_ == kAuthFailed; }
private:
    int type_;
};

} // namespace zoocage

#endif // ZKCLI_STATE_H_
