#include <boost/scoped_array.hpp>
#include <zookeeper/zookeeper.h>
#include "zookeeper.h"
#include "internal/zookeeper_impl.h"

namespace zoocage {

ZooKeeper::ZooKeeper()
    : impl_(new ZooKeeperImpl())
{
}

ZooKeeper::~ZooKeeper()
{
    delete impl_;
}

Status ZooKeeper::Init(const std::string& dest, int timeout, Watcher* watcher) {
    return impl_->Init(dest, timeout, watcher);
}

Status ZooKeeper::Close() {
    return impl_->Close();
}

Status ZooKeeper::AddAuth(const std::string& scheme, const std::string& cert) {
    return impl_->AddAuth(scheme, cert);
}

Status ZooKeeper::AddAuth(const std::string& scheme, const std::string& cert,
        const AddAuthCallback& callback) {
    return impl_->AddAuth(scheme, cert, callback);
}

Status ZooKeeper::Create(const std::string& path, const std::string& value,
        const std::vector<Acl>& acls, mode::Type mode,
        std::string* path_created) {
    return impl_->Create(path, value, acls, mode, path_created);
}

Status ZooKeeper::Create(const std::string& path, const std::string& value,
        const std::vector<Acl>& acls, mode::Type mode,
        const CreateCallback& callback) {
    return impl_->Create(path, value, acls, mode, callback);
}

Status ZooKeeper::Delete(const std::string& path, int32_t version) {
    return impl_->Delete(path, version);
}

Status ZooKeeper::Delete(const std::string& path, int32_t version,
        const DeleteCallback& callback) {
    return impl_->Delete(path, version, callback);
}

Status ZooKeeper::Exists(const std::string& path, Watcher* watcher, Stat* stat) {
    return impl_->Exists(path, watcher, stat);
}

Status ZooKeeper::Exists(const std::string& path, bool watch, Stat* stat) {
    return impl_->Exists(path, watch, stat);
}

Status ZooKeeper::Exists(const std::string& path, Watcher* watcher,
        const ExistsCallback& callback) {
    return impl_->Exists(path, watcher, callback);
}

Status ZooKeeper::Exists(const std::string& path, bool watch,
        const ExistsCallback& callback) {
    return impl_->Exists(path, watch, callback);
}

Status ZooKeeper::Get(const std::string& path, Watcher* watcher, 
        std::string* value, Stat* stat) {
    return impl_->Get(path, watcher, value, stat);
}

Status ZooKeeper::Get(const std::string& path, bool watch,
        std::string* value, Stat* stat) {
    return impl_->Get(path, watch, value, stat);
}

Status ZooKeeper::Get(const std::string& path, Watcher* watcher,
        const GetCallback& callback) {
    return impl_->Get(path, watcher, callback);
}

Status ZooKeeper::Get(const std::string& path, bool watch,
        const GetCallback& callback) {
    return impl_->Get(path, watch, callback);
}

Status ZooKeeper::Set(const std::string& path, const std::string& value,
        int32_t version, Stat* stat) {
    return impl_->Set(path, value, version, stat);
}

Status ZooKeeper::Set(const std::string& path, const std::string& value,
        int32_t version, const SetCallback& callback) {
    return impl_->Set(path, value, version, callback);
}

Status ZooKeeper::GetAcl(const std::string& path, std::vector<Acl>* acls,
        Stat* stat) {
    return impl_->GetAcl(path, acls, stat);
}

Status ZooKeeper::GetAcl(const std::string& path, const GetAclCallback& callback) {
    return impl_->GetAcl(path, callback);
}

Status ZooKeeper::SetAcl(const std::string& path, const std::vector<Acl>& acls,
        int32_t version) {
    return impl_->SetAcl(path, acls, version);
}

Status ZooKeeper::SetAcl(const std::string& path, const std::vector<Acl>& acls,
        int32_t version, const SetAclCallback& callback) {
    return impl_->SetAcl(path, acls, version, callback);
}

Status ZooKeeper::GetChildren(const std::string& path, Watcher* watcher,
        std::vector<std::string>* children) {
    return impl_->GetChildren(path, watcher, children);
}

Status ZooKeeper::GetChildren(const std::string& path, bool watch,
        std::vector<std::string>* children) {
    return impl_->GetChildren(path, watch, children);
}

Status ZooKeeper::GetChildren(const std::string& path, Watcher* watcher,
        const GetChildrenCallback& callback) {
    return impl_->GetChildren(path, watcher, callback);
}

Status ZooKeeper::GetChildren(const std::string& path, bool watch,
        const GetChildrenCallback& callback) {
    return impl_->GetChildren(path, watch, callback);
}

Status ZooKeeper::GetChildrenWithStat(const std::string& path, Watcher* watcher,
        std::vector<std::string>* children, Stat* stat) {
    return impl_->GetChildrenWithStat(path, watcher, children, stat);
}

Status ZooKeeper::GetChildrenWithStat(const std::string& path, bool watch,
        std::vector<std::string>* children, Stat* stat) {
    return impl_->GetChildrenWithStat(path, watch, children, stat);
}

Status ZooKeeper::GetChildrenWithStat(const std::string& path, Watcher* watcher,
        const GetChildrenWithStatCallback& callback) {
    return impl_->GetChildrenWithStat(path, watcher, callback);
}

Status ZooKeeper::GetChildrenWithStat(const std::string& path, bool watch,
        const GetChildrenWithStatCallback& callback) {
    return impl_->GetChildrenWithStat(path, watch, callback);
}

Status ZooKeeper::Multi(const boost::ptr_vector<Op>& ops,
        boost::ptr_vector<Op::Result>* results) {
    return impl_->Multi(ops, results);
}

Status ZooKeeper::Multi(const boost::ptr_vector<Op>& ops,
        const MultiCallback& callback) {
    return impl_->Multi(ops, callback);
}

} // namespace zoocage

