#ifndef ZOOCAGE_CALLBACKS_H_
#define ZOOCAGE_CALLBACKS_H_

#include <string>
#include <vector>
#include <tr1/functional>
#include "stat.h"
#include "status.h"
#include "result.h"

namespace zoocage {

typedef std::tr1::function<void(const CreateResult&)>
    CreateCallback;
typedef std::tr1::function<void(const DeleteResult&)>
    DeleteCallback;
typedef std::tr1::function<void(const ExistsResult&)>
    ExistsCallback;
typedef std::tr1::function<void(const GetResult&)>
    GetCallback;
typedef std::tr1::function<void(const SetResult&)>
    SetCallback;
typedef std::tr1::function<void(const GetChildrenResult&)>
    GetChildrenCallback;
typedef std::tr1::function<void(const GetChildrenWithStatResult&)>
    GetChildrenWithStatCallback;
typedef std::tr1::function<void(const GetAclResult&)>
    GetAclCallback;
typedef std::tr1::function<void(const SetAclResult&)>
    SetAclCallback;
typedef std::tr1::function<void(const AddAuthResult&)>
    AddAuthCallback;
typedef std::tr1::function<void(const MultiResult&)>
    MultiCallback;

} // namespace zoocage

#endif // ZOOCAGE_CALLBACKS_H_
