/*
 * =============================================================================
 *
 *       Filename:  watcher.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  03/26/2012 18:06:50
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Xinjie Li (jasonli), xjason.li@gmail.com
 *        Company:  Qihoo inc.
 *
 * =============================================================================
 */

#ifndef ZKCLI_WATCHER_H_
#define ZKCLI_WATCHER_H_

#include <zookeeper/zookeeper.h>
#include "watched_event.h"

namespace zoocage {

class Watcher {
public:
    virtual ~Watcher() {}
    virtual void Process(const WatchedEvent& ev) = 0;
};

} // namespace zoocage


#endif // ZKCLI_WATCHER_H_
