/*
 * =============================================================================
 *
 *       Filename:  state.cc
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  04/01/2012 15:30:30
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Xinjie Li (jasonli), xjason.li@gmail.com
 *        Company:  Qihoo inc.
 *
 * =============================================================================
 */

#include "state.h"

namespace zoocage {

const char *State::ToString() const {
    if (type_ == 0) {
        return "ZOO_CLOSED_STATE";
    } else if (type_ == kConnecting) {
        return "ZOO_CONNECTING_STATE";
    } else if (type_ == kAssociating) {
        return "ZOO_ASSOCIATING_STATE";
    } else if (type_ == kConnected) {
        return "ZOO_CONNECTED_STATE";
    } else if (type_ == kSessionExpired) {
        return "ZOO_EXPIRED_SESSION_STATE";
    } else if (type_ == kAuthFailed) {
        return "ZOO_AUTH_FAILED_STATE";
    }
    return "INVALID_STATE";
}

} // namespace zoocage
