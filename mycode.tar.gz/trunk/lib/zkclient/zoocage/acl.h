/*
 * =============================================================================
 *
 *       Filename:  acl.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  03/28/2012 17:24:59
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Xinjie Li (jasonli), xjason.li@gmail.com
 *        Company:  Qihoo inc.
 *
 * =============================================================================
 */

#ifndef ZKCLI_ACL_H_
#define ZKCLI_ACL_H_

#include <zookeeper/zookeeper.jute.h>

namespace zoocage {

class Id {
public:
    Id() {}
    std::string& scheme() { return scheme_; }
    std::string& id() { return id_; }

    // Convertion from ::Id
    Id(const ::Id & id) { *this = id; }
    const Id& operator = (const ::Id &id) {
        if (id.scheme) {
            scheme_.assign(id.scheme);
        }
        if (id.id) {
            id_.assign(id.id);
        }
        return *this;
    }
    // Convertion to ::Id
    operator ::Id() const {
        ::Id id;
        id.scheme = strdup(scheme_.c_str());
        id.id = strdup(id_.c_str());
        return id;
    }
private:
    std::string scheme_;
    std::string id_;
};

class Acl {
public:
    Acl(): perms_(0) {}
    ~Acl() {}
    int32_t& perms() { return perms_; }
    Id& id() { return id_; }

    Acl(const ::ACL& acl) { *this = acl; }
    const Acl& operator = (const ::ACL& acl) {
        perms_ = acl.perms;
        id_ = acl.id;
        return *this;
    }

    operator ::ACL() const {
        ::ACL acl;
        acl.perms = perms_;
        acl.id = id_;
        return acl;
    }

private:
    int32_t perms_;
    Id id_;
};

} // namespace zoocage

#endif // ZKCLI_STAT_H_
