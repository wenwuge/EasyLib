#ifndef ZOOCAGE_INTERNAL_ZK_CALLBACK_H_
#define ZOOCAGE_INTERNAL_ZK_CALLBACK_H_

#include "zookeeper/zookeeper.h"
#include "../zookeeper.h"
#include "synchronizer.h"

namespace zoocage {
namespace functions {

void Watcher1(zhandle_t *zh, int event, int state, const char *path,
        void *context);

void Watcher2(zhandle_t *zh, int event, int state, const char *path,
        void *context);

void CreateCompletion(int rc, const char *name, const void *ptr);
void DeleteCompletion(int rc, const void *ptr);
void ExistsCompletion(int rc, const struct ::Stat *stat,
        const void *ptr);
void GetCompletion(int rc, const char *value, int value_len,
        const struct ::Stat *stat, const void *ptr);
void SetCompletion(int rc, const struct ::Stat *stat,
        const void *ptr);
void GetAclCompletion(int rc, struct ::ACL_vector* acls, 
        struct ::Stat* stat, const void *ptr);
void SetAclCompletion(int rc, const void* ptr);
void GetChildrenCompletion(int rc, const struct String_vector *strings, 
        const void *ptr);
void GetChildrenWithStatCompletion(int rc,
        const struct String_vector *strings, const struct ::Stat *stat,
        const void *ptr);
void AddAuthCompletion(int rc, const void* ptr);
void MultiCompletion(int rc, const void* ptr);

} // namespace functions
} // naemspace zoocage

#endif // ZOOCAGE_INTERNAL_ZK_CALLBACK_H_
