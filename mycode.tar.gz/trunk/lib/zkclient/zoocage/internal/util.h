#ifndef ZOOCAGE_INTERNAL_UTIL_H_
#define ZOOCAGE_INTERNAL_UTIL_H_

#include <string>
#include <boost/interprocess/detail/atomic.hpp>
#include <boost/noncopyable.hpp>
#include "../mode.h"

namespace zoocage {
namespace util {

inline size_t MaxCreatedPathLength(const std::string& path, mode::Type mode) {
    size_t len = path.size();
    if (mode & mode::kPersistentSequence) {
        const size_t kSequenceSuffixLength = 11;
        len += kSequenceSuffixLength;
    }
    return len + 1;
}

template <class T>
class ArrayGuard : boost::noncopyable {
public:
    ArrayGuard(T* arr = NULL) : arr_(arr) {}
    ~ArrayGuard() { delete [] arr_; }
    void Release() { arr_ = NULL; }
private:
    T* arr_;
};

template <class T>
class PtrGuard : boost::noncopyable {
public:
    PtrGuard(T* ptr = NULL) : ptr_(ptr) {}
    ~PtrGuard() { delete ptr_; }
    void Release() { ptr_ = NULL; }
private:
    T* ptr_;
};

using boost::interprocess::detail::atomic_cas32;
using boost::interprocess::detail::atomic_write32;
using boost::interprocess::detail::atomic_read32;


} // namespace util
} // namespace zoocage

#endif // ZOOCAGE_INTERNAL_UTIL_H_
