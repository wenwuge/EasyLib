#ifndef ZOOCAGE_INTERNAL_CALLBACK_WRAPPER_H_
#define ZOOCAGE_INTERNAL_CALLBACK_WRAPPER_H_

#include <set>
#include <tr1/functional>
#include "logging.h"
#include "../callback.h"
#include "../result.h"
#include "../op.h"

namespace zoocage {

class CallbackWrapperIf {
public:
    virtual ~CallbackWrapperIf() {}
};

template <class ResultT>
class CallbackWrapperBase : public CallbackWrapperIf {
public:
    CallbackWrapperBase(const std::tr1::function<void(const ResultT&)>& callback)
        : callback_(callback) {}
    void ProcessResult(ResultT *result) {
        PrepareForCalling();
        try {
            callback_(*result);
        } catch (const std::exception &e) {
            LOG(ERROR) << "Caught exception: " << e.what();
        }
        delete this;
    }
protected:
    virtual void PrepareForCalling() {}
    std::tr1::function<void(const ResultT&)> callback_;
};

template <class ResultT>
class CallbackWrapper : public CallbackWrapperBase<ResultT> {
    typedef CallbackWrapperBase<ResultT> BaseT;
public:
    CallbackWrapper(const std::string &path,
            const std::tr1::function<void(const ResultT&)>& callback)
        : BaseT(callback), path_(path) {}

    const std::string &path() const { return path_; }
private:
    std::string path_;
};

template <>
class CallbackWrapper<AddAuthResult> 
    : public CallbackWrapperBase<AddAuthResult> {
    typedef CallbackWrapperBase<AddAuthResult> BaseT;
public:
    CallbackWrapper(const std::string& scheme, const std::string& cert,
            const std::tr1::function<void(const AddAuthResult&)>& callback)
        : BaseT(callback), scheme_(scheme), cert_(cert) {}
    
    const std::string& scheme() const { return scheme_; }
    const std::string& cert() const { return cert_; }
private:
    std::string scheme_;
    std::string cert_;
};

template <>
class CallbackWrapper<MultiResult> 
    : public CallbackWrapperBase<MultiResult> {
    typedef CallbackWrapperBase<MultiResult> BaseT;
public:
    CallbackWrapper(size_t count, 
            const std::tr1::function<void(const MultiResult&)>& callback)
        : BaseT(callback) , count_(count)
        , zresults_(new zoo_op_result_t[count]) {}
    virtual ~CallbackWrapper() {
        delete [] zresults_;
    }
    virtual void PrepareForCalling() {
        for (int i = 0; i < static_cast<int>(count_); ++i) {
            int rc = zresults_[i].err;
            results_[i].Update(rc);
        }
    }

    const size_t count() const { return count_; }
    zoo_op_result_t* zresults() const { return zresults_; }
    boost::ptr_vector<Op::Result>& results() { return results_; }

    const boost::ptr_vector<Op::Result>& results() const { return results_; }
private:
    size_t count_;
    zoo_op_result_t* zresults_;
    boost::ptr_vector<Op::Result> results_;
};

} // namespace zoocage

#endif // ZOOCAGE_INTERNAL_CALLBACK_WRAPPER_H_
