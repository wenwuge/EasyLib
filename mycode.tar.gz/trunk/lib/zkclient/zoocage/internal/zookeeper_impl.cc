#include <boost/scoped_array.hpp>
#include <zookeeper/zookeeper.h>
#include "zookeeper_impl.h"
#include "util.h"
#include "functions.h"
#include "logging.h"
#include "callback_wrapper.h"
#include "synchronizer.h"

namespace zoocage {

ZooKeeperImpl::ZooKeeperImpl()
    : zh_(NULL)
    , watcher_(NULL)
    , initer_(NULL)
    , free_initer_(0)
{
}

ZooKeeperImpl::~ZooKeeperImpl()
{
    Close();
}

Status ZooKeeperImpl::Init(const std::string& dest, int timeout, Watcher* watcher) {
    CHECK_EQ(zh_, (zhandle_t*)NULL);
    CHECK_GE(timeout, 0);
    CHECK_EQ(watcher_, (Watcher*)NULL);

    if (watcher_) {
        watcher_ = watcher;
        initer_ = new Synchronizer();
        util::atomic_write32(&free_initer_, 1);
    }
    zh_ = zookeeper_init(dest.c_str(), watcher ? functions::Watcher1 : NULL,
            timeout, NULL, this, 0);
    Status status;
    if (zh_) {
        if (watcher_) {
            initer_->Notify();
        }
    } else {
        status = errno;
        if (watcher_) {
            util::atomic_write32(&free_initer_, 0);
            delete initer_;
            initer_ = NULL;
            watcher_ = NULL;
        }
    }
    return status;
}

Status ZooKeeperImpl::Close() {
    Status status;
    if (zh_) {
        status = zookeeper_close(zh_);
        if (status.ok()) {
            zh_ = NULL;
        }
        if (watcher_) {
            uint32_t need_free = util::atomic_cas32(&free_initer_, 0, 1);
            if (need_free) {
                delete initer_;
                initer_ = NULL;
            }
            watcher_ = NULL;
        }
    }
    return status;
}

Status ZooKeeperImpl::AddAuth(const std::string& scheme, const std::string& cert) {
    CHECK_NOTNULL(zh_);
    SynchronizerCallback<AddAuthResult> scb;
    Status status = AddAuth(scheme, cert, scb);
    if (status.ok()) {
        status = scb.Wait();
    }
    return status;
}

Status ZooKeeperImpl::AddAuth(const std::string& scheme, const std::string& cert,
        const AddAuthCallback& callback) {
    CHECK_NOTNULL(zh_);
    std::auto_ptr<CallbackWrapperIf> cb(
            new CallbackWrapper<AddAuthResult>(scheme, cert, callback));
    Status status = zoo_add_auth(zh_, scheme.c_str(), cert.c_str(), cert.size(), 
            functions::AddAuthCompletion, cb.get());
    if (status.ok()) {
        cb.release();
    }
    return status;
}

Status ZooKeeperImpl::Create(const std::string& path, const std::string& value,
        const std::vector<Acl>& acls, mode::Type mode,
        std::string* path_created) {
    CHECK_NOTNULL(zh_);
    SynchronizerCallback<CreateResult> scb(path_created);
    Status status = Create(path, value, acls, mode, scb);
    if (status.ok()) {
        status = scb.Wait();
    }
    return status;
}

Status ZooKeeperImpl::Create(const std::string& path, const std::string& value,
        const std::vector<Acl>& acls, mode::Type mode,
        const CreateCallback& callback) {
    CHECK_NOTNULL(zh_);
    struct ACL_vector aclv;
    allocate_ACL_vector(&aclv, acls.size());
    std::copy(acls.begin(), acls.end(), aclv.data);

    std::auto_ptr<CallbackWrapperIf> cb(
            new CallbackWrapper<CreateResult>(path, callback));
    Status status = zoo_acreate(zh_, path.c_str(), value.data(), value.size(),
            &aclv, mode, functions::CreateCompletion, cb.get());
    deallocate_ACL_vector(&aclv);
    if (status.ok()) {
        cb.release();
    }
    return status;
}

Status ZooKeeperImpl::Delete(const std::string& path, int32_t version) {
    CHECK_NOTNULL(zh_);
    SynchronizerCallback<DeleteResult> scb;
    Status status = Delete(path, version, scb);
    if (status.ok()) {
        status = scb.Wait();
    }
    return status;
}

Status ZooKeeperImpl::Delete(const std::string& path, int32_t version,
        const DeleteCallback& callback) {
    CHECK_NOTNULL(zh_);
    std::auto_ptr<CallbackWrapperIf> cb(
            new CallbackWrapper<DeleteResult>(path, callback));
    Status status = zoo_adelete(zh_, path.c_str(), version,
            functions::DeleteCompletion, cb.get());
    if (status.ok()) {
        cb.release();
    }
    return status;
}

Status ZooKeeperImpl::Exists(const std::string& path, Watcher* watcher, Stat* stat) {
    CHECK_NOTNULL(zh_);
    SynchronizerCallback<ExistsResult> scb(stat);
    Status status = Exists(path, watcher, scb);
    if (status.ok()) {
        status = scb.Wait();
    }
    return status;
}

Status ZooKeeperImpl::Exists(const std::string& path, bool watch, Stat* stat) {
    CHECK_NOTNULL(zh_);
    SynchronizerCallback<ExistsResult> scb(stat);
    Status status = Exists(path, watch, scb);
    if (status.ok()) {
        status = scb.Wait();
    }
    return status;
}

Status ZooKeeperImpl::Exists(const std::string& path, Watcher* watcher,
        const ExistsCallback& callback) {
    CHECK_NOTNULL(zh_);
    std::auto_ptr<CallbackWrapperIf> cb(
            new CallbackWrapper<ExistsResult>(path, callback));
    Status status = zoo_awexists(zh_, path.c_str(),
            watcher ? functions::Watcher2 : NULL, watcher,
            functions::ExistsCompletion, cb.get());
    if (status.ok()) {
        cb.release();
    }
    return status;
}

Status ZooKeeperImpl::Exists(const std::string& path, bool watch,
        const ExistsCallback& callback) {
    CHECK_NOTNULL(zh_);
    std::auto_ptr<CallbackWrapperIf> cb(
            new CallbackWrapper<ExistsResult>(path, callback));
    Status status = zoo_aexists(zh_, path.c_str(), watch,
            functions::ExistsCompletion, cb.get());
    if (status.ok()) {
        cb.release();
    }
    return status;
}

Status ZooKeeperImpl::Get(const std::string& path, Watcher* watcher, 
        std::string* value, Stat* stat) {
    CHECK_NOTNULL(zh_);
    SynchronizerCallback<GetResult> scb(value, stat);
    Status status = Get(path, watcher, scb);
    if (status.ok()) {
        status = scb.Wait();
    }
    return status;
}

Status ZooKeeperImpl::Get(const std::string& path, bool watch,
        std::string* value, Stat* stat) {
    CHECK_NOTNULL(zh_);
    SynchronizerCallback<GetResult> scb(value, stat);
    Status status = Get(path, watch, scb);
    if (status.ok()) {
        status = scb.Wait();
    }
    return status;
}

Status ZooKeeperImpl::Get(const std::string& path, Watcher* watcher,
        const GetCallback& callback) {
    CHECK_NOTNULL(zh_);
    std::auto_ptr<CallbackWrapperIf> cb(
            new CallbackWrapper<GetResult>(path, callback));
    Status status = zoo_awget(zh_, path.c_str(),
            watcher ? functions::Watcher2 : NULL, watcher,
            functions::GetCompletion, cb.get());
    if (status.ok()) {
        cb.release();
    }
    return status;
}

Status ZooKeeperImpl::Get(const std::string& path, bool watch,
        const GetCallback& callback) {
    CHECK_NOTNULL(zh_);
    std::auto_ptr<CallbackWrapperIf> cb(
            new CallbackWrapper<GetResult>(path, callback));
    Status status = zoo_aget(zh_, path.c_str(), watch, 
            functions::GetCompletion, cb.get());
    if (status.ok()) {
        cb.release();
    }
    return status;
}

Status ZooKeeperImpl::Set(const std::string& path, const std::string& value,
        int32_t version, Stat* stat) {
    CHECK_NOTNULL(zh_);
    SynchronizerCallback<SetResult> scb(stat);
    Status status = Set(path, value, version, scb);
    if (status.ok()) {
        status = scb.Wait();
    }
    return status;
}

Status ZooKeeperImpl::Set(const std::string& path, const std::string& value,
        int32_t version, const SetCallback& callback) {
    CHECK_NOTNULL(zh_);
    std::auto_ptr<CallbackWrapperIf> cb(
            new CallbackWrapper<SetResult>(path, callback));
    Status status = zoo_aset(zh_, path.c_str(), value.data(), value.size(),
            version, functions::SetCompletion, cb.get());
    if (status.ok()) {
        cb.release();
    }
    return status;
}

Status ZooKeeperImpl::GetAcl(const std::string& path, std::vector<Acl>* acls,
        Stat* stat) {
    CHECK_NOTNULL(zh_);
    SynchronizerCallback<GetAclResult> scb(acls, stat);
    Status status = GetAcl(path, scb);
    if (status.ok()) {
        status = scb.Wait();
    }
    return status;
}

Status ZooKeeperImpl::GetAcl(const std::string& path, const GetAclCallback& callback) {
    CHECK_NOTNULL(zh_);
    std::auto_ptr<CallbackWrapperIf> cb(
            new CallbackWrapper<GetAclResult>(path, callback));
    Status status = zoo_aget_acl(zh_, path.c_str(), functions::GetAclCompletion,
            cb.get());
    if (status.ok()) {
        cb.release();
    }
    return status;
}

Status ZooKeeperImpl::SetAcl(const std::string& path, const std::vector<Acl>& acls,
        int32_t version) {
    CHECK_NOTNULL(zh_);
    SynchronizerCallback<SetAclResult> scb;
    Status status = SetAcl(path, acls, version, scb);
    if (status.ok()) {
        status = scb.Wait();
    }
    return status;
}

Status ZooKeeperImpl::SetAcl(const std::string& path, const std::vector<Acl>& acls,
        int32_t version, const SetAclCallback& callback) {
    CHECK_NOTNULL(zh_);
    struct ACL_vector aclv;
    allocate_ACL_vector(&aclv, acls.size());
    std::copy(acls.begin(), acls.end(), aclv.data);

    std::auto_ptr<CallbackWrapperIf> cb(
            new CallbackWrapper<SetAclResult>(path, callback));
    Status status = zoo_aset_acl(zh_, path.c_str(), version, &aclv,
            functions::SetAclCompletion, cb.get());
    deallocate_ACL_vector(&aclv);
    if (status.ok()) {
        cb.release();
    }
    return status;
}

Status ZooKeeperImpl::GetChildren(const std::string& path, Watcher* watcher,
        std::vector<std::string>* children) {
    CHECK_NOTNULL(zh_);
    SynchronizerCallback<GetChildrenResult> scb(children);
    Status status = GetChildren(path, watcher, scb);
    if (status.ok()) {
        status = scb.Wait();
    }
    return status;
}

Status ZooKeeperImpl::GetChildren(const std::string& path, bool watch,
        std::vector<std::string>* children) {
    CHECK_NOTNULL(zh_);
    SynchronizerCallback<GetChildrenResult> scb(children);
    Status status = GetChildren(path, watch, scb);
    if (status.ok()) {
        status = scb.Wait();
    }
    return status;
}

Status ZooKeeperImpl::GetChildren(const std::string& path, Watcher* watcher,
        const GetChildrenCallback& callback) {
    CHECK_NOTNULL(zh_);
    std::auto_ptr<CallbackWrapperIf> cb(
            new CallbackWrapper<GetChildrenResult>(path, callback));
    Status status = zoo_awget_children(zh_, path.c_str(),
            watcher ? functions::Watcher2 : NULL, watcher,
            functions::GetChildrenCompletion, cb.get());
    if (status.ok()) {
        cb.release();
    }
    return status;
}

Status ZooKeeperImpl::GetChildren(const std::string& path, bool watch,
        const GetChildrenCallback& callback) {
    CHECK_NOTNULL(zh_);
    std::auto_ptr<CallbackWrapperIf> cb(
            new CallbackWrapper<GetChildrenResult>(path, callback));
    Status status = zoo_aget_children(zh_, path.c_str(), watch,
            functions::GetChildrenCompletion, cb.get());
    if (status.ok()) {
        cb.release();
    }
    return status;
}

Status ZooKeeperImpl::GetChildrenWithStat(const std::string& path, Watcher* watcher,
        std::vector<std::string>* children, Stat* stat) {
    CHECK_NOTNULL(zh_);
    SynchronizerCallback<GetChildrenWithStatResult> scb(children, stat);
    Status status = GetChildrenWithStat(path, watcher, scb);
    if (status.ok()) {
        status = scb.Wait();
    }
    return status;
}

Status ZooKeeperImpl::GetChildrenWithStat(const std::string& path, bool watch,
        std::vector<std::string>* children, Stat* stat) {
    CHECK_NOTNULL(zh_);
    SynchronizerCallback<GetChildrenWithStatResult> scb(children, stat);
    Status status = GetChildrenWithStat(path, watch, scb);
    if (status.ok()) {
        status = scb.Wait();
    }
    return status;
}

Status ZooKeeperImpl::GetChildrenWithStat(const std::string& path, Watcher* watcher,
        const GetChildrenWithStatCallback& callback) {
    CHECK_NOTNULL(zh_);
    std::auto_ptr<CallbackWrapperIf> cb(
            new CallbackWrapper<GetChildrenWithStatResult>(path, callback));
    Status status = zoo_awget_children2(zh_, path.c_str(),
            watcher ? functions::Watcher2 : NULL, watcher,
            functions::GetChildrenWithStatCompletion, cb.get());
    if (status.ok()) {
        cb.release();
    }
    return status;
}

Status ZooKeeperImpl::GetChildrenWithStat(const std::string& path, bool watch,
        const GetChildrenWithStatCallback& callback) {
    CHECK_NOTNULL(zh_);
    std::auto_ptr<CallbackWrapperIf> cb(
            new CallbackWrapper<GetChildrenWithStatResult>(path, callback));
    Status status = zoo_aget_children2(zh_, path.c_str(), watch,
            functions::GetChildrenWithStatCompletion, cb.get());
    if (status.ok()) {
        cb.release();
    }
    return status;
}

Status ZooKeeperImpl::Multi(const boost::ptr_vector<Op>& ops,
        boost::ptr_vector<Op::Result>* results) {
    CHECK_NOTNULL(zh_);
    SynchronizerCallback<MultiResult> scb(results);
    Status status = Multi(ops, scb);
    if (status.ok()) {
        status = scb.Wait();
    }
    return status;
}

Status ZooKeeperImpl::Multi(const boost::ptr_vector<Op>& ops,
        const MultiCallback& callback) {
    CHECK_NOTNULL(zh_);
    std::auto_ptr<CallbackWrapper<MultiResult> > cb(
            new CallbackWrapper<MultiResult>(ops.size(), callback));

    boost::scoped_array<zoo_op_t> zops(new zoo_op_t[ops.size()]);
    int idx = 0;
    for (boost::ptr_vector<Op>::const_iterator it = ops.begin();
            it != ops.end(); ++it, ++idx) {
        Op::Result* result = it->MakeResult(&zops[idx]);
        cb->results().push_back(result);
    }
    CHECK_EQ(cb->results().size(), cb->count());

    Status status = zoo_amulti(zh_, ops.size(), zops.get(),
            cb->zresults(), functions::MultiCompletion, cb.get());
    if (status.ok()) {
        cb.release();
    }
    return status;
}


} // namespace zoocage
