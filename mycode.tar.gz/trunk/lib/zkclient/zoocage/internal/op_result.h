#ifndef ZOOCAGE_INTERNAL_OP_RESULT_H_
#define ZOOCAGE_INTERNAL_OP_RESULT_H_

#include "../op.h"
#include "util.h"

namespace zoocage {

class OpResultBase : public Op::Result {
public:
    OpResultBase(const std::string& path)
        : path_(path) {}
    virtual Status status() const { return Status(rc_); }
    virtual const std::string& path() const { return path_; }
    virtual Op::Type type() const = 0;

    virtual const std::string* path_created() const { return NULL; }
    virtual const Stat* stat_set() const { return NULL; }
    virtual void Update(int rc) { rc_ = rc; UpdateBuffer(); }
protected:
    virtual void UpdateBuffer() {};
    int rc_;
    std::string path_;
};

class OpCreateResult : public OpResultBase {
public:
    OpCreateResult(const std::string& path, mode::Type mode)
        : OpResultBase(path) , mode_(mode) , buffer_(NULL) {
        size_t n = buflen();
        buffer_ = static_cast<char*>(calloc(n, 1));
    }
    virtual ~OpCreateResult() { free(buffer_); }
    virtual Op::Type type() const { return Op::kCreate; }
    virtual const std::string* path_created() const { return &path_created_; }

    virtual void UpdateBuffer() { path_created_.assign(buffer_); }
    char* buffer() const { return buffer_; }
    size_t buflen() const { return util::MaxCreatedPathLength(path_, mode_); }
private:
    mode::Type mode_;

    char* buffer_;
    std::string path_created_;
};

class OpDeleteResult : public OpResultBase {
public:
    OpDeleteResult(const std::string& path) : OpResultBase(path) {}
    virtual Op::Type type() const { return Op::kDelete; }
};

class OpSetResult : public OpResultBase {
public:
    OpSetResult(const std::string& path) : OpResultBase(path) {}
    virtual Op::Type type() const { return Op::kDelete; }
    virtual const Stat* stat_set() const { return &stat_; }
    virtual void UpdateBuffer() { stat_ = buffer_; }

    ::Stat* buffer() { return &buffer_; }
private:
    ::Stat buffer_;
    Stat stat_;
};

class OpCheckResult : public OpResultBase {
public:
    OpCheckResult(const std::string& path) : OpResultBase(path) {}
    virtual Op::Type type() const { return Op::kCheck; }
};

} // namespace zoocage

#endif // ZOOCAGE_INTERNAL_OP_RESULT_H_
