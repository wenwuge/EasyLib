#ifndef ZOOCAGE_ZOOKEEPER_IMPL_H_
#define ZOOCAGE_ZOOKEEPER_IMPL_H_

#include <boost/noncopyable.hpp>
#include "../zookeeper.h"
#include "synchronizer.h"
#include "functions.h"

namespace zoocage {

class ZooKeeperImpl : boost::noncopyable {
public:
    ZooKeeperImpl();
    ~ZooKeeperImpl();

    Status Init(const std::string& dest, int timeout, Watcher* watcher);
    Status Close();

    Status AddAuth(const std::string& scheme, const std::string& cert);
    Status AddAuth(const std::string& scheme, const std::string& cert,
            const AddAuthCallback& callback);

    Status Create(const std::string& path, const std::string& value,
            const std::vector<Acl>& acls, mode::Type mode,
            std::string* path_created);
    Status Create(const std::string& path, const std::string& value,
            const std::vector<Acl>& acls, mode::Type mode,
            const CreateCallback& callback);

    Status Delete(const std::string& path, int32_t version);
    Status Delete(const std::string& path, int32_t version,
            const DeleteCallback& callback);

    Status Exists(const std::string& path, Watcher* watcher, Stat* stat);
    Status Exists(const std::string& path, bool watch, Stat* stat);
    Status Exists(const std::string& path, Watcher* watcher,
            const ExistsCallback& callback);
    Status Exists(const std::string& path, bool watch,
            const ExistsCallback& callback);

    Status Get(const std::string& path, Watcher* watcher, 
            std::string* value, Stat* stat);
    Status Get(const std::string& path, bool watch,
            std::string* value, Stat* stat);
    Status Get(const std::string& path, Watcher* watcher,
            const GetCallback& callback);
    Status Get(const std::string& path, bool watch,
            const GetCallback& callback);

    Status Set(const std::string& path, const std::string& value, int32_t version, 
            Stat* stat);
    Status Set(const std::string& path, const std::string& value, int32_t version,
            const SetCallback& callback);

    Status GetAcl(const std::string& path, std::vector<Acl>* acls,
            Stat* stat);
    Status GetAcl(const std::string& path, const GetAclCallback& callback);

    Status SetAcl(const std::string& path, const std::vector<Acl>& acls,
            int32_t version);
    Status SetAcl(const std::string& path, const std::vector<Acl>& acls,
            int32_t version, const SetAclCallback& callback);

    Status GetChildren(const std::string& path, Watcher* watcher,
            std::vector<std::string>* children);
    Status GetChildren(const std::string& path, bool watch,
            std::vector<std::string>* children);
    Status GetChildren(const std::string& path, Watcher* watcher,
            const GetChildrenCallback& callback);
    Status GetChildren(const std::string& path, bool watch,
            const GetChildrenCallback& callback);

    Status GetChildrenWithStat(const std::string& path, Watcher* watcher,
            std::vector<std::string>* children, Stat* stat);
    Status GetChildrenWithStat(const std::string& path, bool watch,
            std::vector<std::string>* children, Stat* stat);
    Status GetChildrenWithStat(const std::string& path, Watcher* watcher,
            const GetChildrenWithStatCallback& callback);
    Status GetChildrenWithStat(const std::string& path, bool watch,
            const GetChildrenWithStatCallback& callback);

    Status Multi(const boost::ptr_vector<Op>& ops,
            boost::ptr_vector<Op::Result>* results);
    Status Multi(const boost::ptr_vector<Op>& ops,
            const MultiCallback& callback);

private:
    friend void functions::Watcher1(zhandle_t*, int, int, const char*, void*);

    zhandle_t* zh_;
    Watcher* watcher_;
    Synchronizer* initer_;
    uint32_t free_initer_;;
};

} // namespace zoocage

#endif // ZOOCAGE_ZOOKEEPER_IMPL_H_
