/*
 * =============================================================================
 *
 *       Filename:  create_wrapper.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  03/30/2012 19:23:22
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Xinjie Li (jasonli), xjason.li@gmail.com
 *        Company:  Qihoo inc.
 *
 * =============================================================================
 */

#ifndef ZKCLI_INTERNAL_CREATE_WRAPPER_H_
#define ZKCLI_INTERNAL_CREATE_WRAPPER_H_

#include "callback_wrapper.h"

namespace zoocage {

class CreateRecursiveCallbackWrapperIf
    : public CallbackWrapper<CreateResult> {
public:
    virtual const std::string &value() const = 0;
    virtual int mode() const = 0;
    virtual zhandle_t *zhandle() const = 0;
protected:
    bool DoRecursive(Status status, Status *status2);
};

class CreateRecursiveCallbackWrapper : public CreateRecursiveCallbackWrapperIf {
public:
    CreateRecursiveCallbackWrapper(const std::string &path,
            const std::string &value, int mode,
            const CreateCallback& cb, zhandle_t *zh)
        : callback_(new CallbackWrapper<CreateResult>(path, cb))
        , value_(value), mode_(mode), zh_(zh) {}

    virtual const std::string &path() const { return callback_->path(); }
    virtual const std::string &value() const { return value_; }
    virtual int mode() const { return mode_; }
    virtual zhandle_t *zhandle() const { return zh_; }
    virtual void ProcessResult(CreateResult *result);
private:
    CallbackWrapper<CreateResult> *callback_;
    std::string value_;
    int mode_;
    zhandle_t *zh_;
};

class CreateParentCallbackWrapper : public CreateRecursiveCallbackWrapperIf {
public:
    CreateParentCallbackWrapper(const std::string &path,
            CreateRecursiveCallbackWrapperIf *child)
        : path_(path), child_(child) {}

    virtual const std::string &path() const { return path_; }
    virtual const std::string &value() const { return value_; }
    virtual int mode() const { return 0; }
    virtual zhandle_t *zhandle() const { return child_->zhandle(); }
    virtual void ProcessResult(CreateResult *result);
private:
    std::string path_;
    CreateRecursiveCallbackWrapperIf *child_;
private:
    static std::string value_;
};

} // namespace zoocage

#endif // ZKCLI_INTERNAL_CREATE_WRAPPER_H_
