/*
 * =============================================================================
 *
 *       Filename:  zkcli.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  03/26/2012 17:53:08
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Xinjie Li (jasonli), xjason.li@gmail.com
 *        Company:  Qihoo inc.
 *
 * =============================================================================
 */

#ifndef ZKCLI_ZKCLI_H_
#define ZKCLI_ZKCLI_H_

#include <zookeeper/zookeeper.h>
#include "callback.h"
#include "status.h"
#include "state.h"

namespace zoocage {

class Watcher;

class ZkCli {
public:
    ZkCli();
    ~ZkCli();

    Status Init(const std::string &hosts, int timeout, Watcher *watcher);
    Status Close();

    State state();

    /**
     * Synchronized methods.
     */
    Status Create(const std::string &path, const std::string& value,
            int mode, 
            std::string* path_created);

    Status CreateRecursive(const std::string &path, const std::string &value,
            int mode,
            std::string* path_created);

    Status Delete(const std::string &path, int version);

    Status DeleteRecursive(const std::string &path, int version);
    
    Status Exists(const std::string &path, Watcher *watcher,
            Stat *stat);

    Status Get(const std::string &path, Watcher *watcher,
            std::string* value,
            Stat *stat);

    Status Set(const std::string &path,const std::string& value, int version,
            Stat* stat);

    Status GetChildren(const std::string &path, Watcher *watcher,
            std::vector<std::string> *childrens);

    Status GetChildren2(const std::string &path, Watcher *watcher,
            std::vector<std::string> *childrens,
            Stat *stat);

    /**
     * Asynchronized methods.
     */
    Status Create(const std::string &path, const std::string& value,
            int mode,
            const CreateCallback &callback);

    Status CreateRecursive(const std::string &path,
            const std::string& value, int mode,
            const CreateCallback &callback);
    
    Status Delete(const std::string &path, int version,
            const DeleteCallback &callback);

    Status DeleteRecursive(const std::string &path, int version,
            const DeleteCallback &callback);

    Status Exists(const std::string &path, Watcher *watcher,
            const ExistsCallback &callback);

    Status Get(const std::string &path, Watcher *watcher,
            const GetCallback &callback);

    Status Set(const std::string &path, const std::string &value,
            int version,
            const SetCallback &callback);

    Status GetChildren(const std::string &path, Watcher *watcher,
            const GetChildrenCallback &callback);
private:
    zhandle_t *handle_;
};

} // namespace zoocage

#endif // ZKCLI_ZKCLI_H_
