/*
 * =============================================================================
 *
 *       Filename:  create_wrapper.cc
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  03/30/2012 19:24:17
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Xinjie Li (jasonli), xjason.li@gmail.com
 *        Company:  Qihoo inc.
 *
 * =============================================================================
 */

#include "create_wrapper.h"
#include "zk_callback.h"
#include "logging.h"
#include "result_impl.h"

namespace zoocage {

std::string CreateParentCallbackWrapper::value_;

bool CreateRecursiveCallbackWrapperIf::DoRecursive(Status status,
        Status *status2) {
    if (status.IsNoNode()) {
        // Create parent node.
        std::string::size_type pos = path().rfind("/");
        CHECK_NE(pos, 0UL);
        CHECK_NE(pos, std::string::npos);
        std::string parent_path = path().substr(0, pos - 1);

        std::auto_ptr<CreateParentCallbackWrapper> parent(
                new CreateParentCallbackWrapper(parent_path, this));

        status = zoo_acreate(zhandle(),
                parent->path().c_str(),
                parent->value().data(), parent->value().size(), 
                &ZOO_OPEN_ACL_UNSAFE, parent->mode(),
                ZkCreateCompletion, parent.get());
        if (status.ok()) {
            // Return and async wait for CreateParentCallbackWrapper
            // completion.
            parent.release();
            return true;
        }
    }
    *status2 = status;
    return false;
}

void CreateRecursiveCallbackWrapper::ProcessResult(CreateResult *result) {
    Status status;
    if (DoRecursive(result->status(), &status)) {
        return;
    }

    if (status != result->status()) {
        CreateResultImpl result2(status.code(), NULL, this);
        callback_->ProcessResult(&result2);
    } else {
        callback_->ProcessResult(result);
    }
    delete this;
}

void CreateParentCallbackWrapper::ProcessResult(CreateResult *result) {
    Status status;
    if (DoRecursive(result->status(), &status)) {
        return;
    }

    if (status.ok() || status.IsNodeExists()) {
        // Parent ok, Create children.
        status = zoo_acreate(zhandle(),
                child_->path().c_str(), 
                child_->value().data(), child_->value().size(),
                &ZOO_OPEN_ACL_UNSAFE, child_->mode(),
                ZkCreateCompletion, child_);
    }

    if (!status.ok()) {
        CreateResultImpl result2(status.code(), NULL, child_);
        result2.Process();
    }
    delete this;
}

} // namespace zoocage
