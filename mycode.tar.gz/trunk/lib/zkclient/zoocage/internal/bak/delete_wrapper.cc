/*
 * =============================================================================
 *
 *       Filename:  delete_wrapper.cc
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  03/30/2012 19:26:29
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Xinjie Li (jasonli), xjason.li@gmail.com
 *        Company:  Qihoo inc.
 *
 * =============================================================================
 */

#include "delete_wrapper.h"
#include "zk_callback.h"
#include "logging.h"
#include "result_impl.h"

namespace zoocage {

bool DeleteRecursiveCallbackWrapperIf::DoRecursive(Status status, Status *status2) {
    if (status.IsNotEmpty()) {
        std::auto_ptr<CallbackWrapperIf> wrapper(
            new GetChildrenAndDeleteCallbackWrapper(this));

        status = zoo_aget_children2(zhandle(), path().c_str(),
                0, ZkGetChildrenCompletion, wrapper.get());
        if (status.ok()) {
            wrapper.release();
            return true;
        }
    }
    *status2 = status;
    return false;
}

void GetChildrenAndDeleteCallbackWrapper::ProcessResult(GetChildrenResult *result) {
    Status status = result->status();
    if (status.ok()) {
        if (!result->children().empty()) {
            // Delete all childrens.
            DeleteChildrenAggregator *aggr =
                new DeleteChildrenAggregator(result->children());
            aggr->Ref();

            std::vector<std::string>::const_iterator it =
                result->children().begin();
            for (; it != result->children().end(); ++it) {
                std::string child_path = path() + "/" + *it;
                std::auto_ptr<DeleteChildrenCallbackWrapper> wrapper(
                    new DeleteChildrenCallbackWrapper(
                            child_path, parent_, aggr));

                status = zoo_adelete(wrapper->zhandle(),
                        wrapper->path().c_str(),
                        wrapper->version(),
                        ZkDeleteCompletion, wrapper.get());
                if (status.ok()) {
                    wrapper.release();
                } else {
                    // Not all adelete operation is launched, so the
                    // aggregator is invalid.
                    // We handle the parent node callback here.
                    break;
                }
            }
            aggr->Unref();
        } else {
            // Delete the node.
            status = zoo_adelete(parent_->zhandle(),
                    parent_->path().c_str(),
                    parent_->version(),
                    ZkDeleteCompletion, parent_);
        }
    }

    if (!status.ok()) {
        DeleteResultImpl result2(status.code(), parent_);
        result2.Process();
    }
    delete this;
}

void DeleteRecursiveCallbackWrapper::ProcessResult(DeleteResult *result) {
    Status status;
    if (DoRecursive(result->status(), &status)) {
        return;
    }
    
    if (status != result->status()) {
        CHECK(!status.ok());

        DeleteResultImpl result2(status.code(), this);
        callback_->ProcessResult(&result2);
    } else {
        callback_->ProcessResult(result);
    }
    delete this;
}

DeleteChildrenAggregator::DeleteChildrenAggregator(
        const std::vector<std::string> &children)
    : children_(children.begin(), children.end())
    , ref_(0)
{
    CHECK_EQ(pthread_mutex_init(&mutex_, NULL), 0);
    CHECK_EQ(pthread_mutex_init(&ref_mtx_, NULL), 0);
}

DeleteChildrenAggregator::~DeleteChildrenAggregator() {
    CHECK_EQ(ref_, 0);
    CHECK_EQ(pthread_mutex_destroy(&mutex_), 0);
    CHECK_EQ(pthread_mutex_destroy(&ref_mtx_), 0);
}

bool DeleteChildrenAggregator::ProcessChild(const std::string &path,
        const Status &status, Status *status2) {
    CHECK_EQ(pthread_mutex_lock(&mutex_), 0);

    CHECK(!children_.empty());
    size_t n = children_.erase(path);
    CHECK_EQ(n, 1UL);
    if (status_.ok() && !status.ok() && !status.IsNoNode()) {
        status_ = status;
    }
    *status2 = status;

    bool ret = children_.empty();
    CHECK_EQ(pthread_mutex_unlock(&mutex_), 0);
    return ret;
}

int DeleteChildrenAggregator::Ref() {
    CHECK_EQ(pthread_mutex_lock(&ref_mtx_), 0);
    int ret = ++ref_;
    CHECK_EQ(pthread_mutex_unlock(&ref_mtx_), 0);
    return ret;
}

int DeleteChildrenAggregator::Unref() {
    CHECK_EQ(pthread_mutex_lock(&ref_mtx_), 0);
    CHECK_GT(ref_, 0);
    int ret = --ref_;
    CHECK_EQ(pthread_mutex_unlock(&ref_mtx_), 0);

    if (ret == 0) {
        delete this;
    }
    return ret;
}

void DeleteChildrenCallbackWrapper::ProcessResult(DeleteResult *result) {
    Status status;
    if (DoRecursive(result->status(), &status)) {
        return;
    }
    Status status2;
    if (aggr_->ProcessChild(path(), status, &status2)) {
        status = status2;
        if (status.ok()) {
            // Delete parent node.
            status = zoo_adelete(zhandle(),
                    parent_->path().c_str(),
                    parent_->version(),
                    ZkDeleteCompletion, parent_);
        }
        if (!status.ok()) {
            // Call parent wrapper.
            DeleteResultImpl result2(status.code(), parent_);
            result2.Process();
        }
    } else {
        // We are not the last callback, not the owner of the aggregator.
        // Or not all callbacks are launched, the aggregator is invalid.
        // Here we just ignore the aggregator.
    }
    delete this;
}

} // namespace zoocage
