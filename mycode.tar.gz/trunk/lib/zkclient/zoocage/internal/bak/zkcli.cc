/*
 * =============================================================================
 *
 *       Filename:  zkcli.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  03/26/2012 18:51:11
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Xinjie Li (jasonli), xjason.li@gmail.com
 *        Company:  Qihoo inc.
 *
 * =============================================================================
 */

#include <errno.h>
#include <boost/scoped_array.hpp>
#include "zkcli.h"
#include "mode.h"
#include "watcher.h"
#include "watched_event.h"
#include "internal/logging.h"
#include "internal/callback_wrapper.h"
#include "internal/zk_callback.h"

namespace zoocage {


using namespace std;

/**
 * Global watcher.
 */
static void ZkWatcher(zhandle_t *zh, int event, int state, const char *path,
        void *context) {
    CHECK_NOTNULL(context);

    std::string path2 =
        (path == NULL || event == ZOO_SESSION_EVENT
            || event == ZOO_NOTWATCHING_EVENT) ? "": path;
    Watcher* watcher = (Watcher*)context;

    WatchedEvent watched_event(event, state, path2);
    try {
        watcher->Process(watched_event);
    } catch (const std::exception& e) {
        LOG(ERROR) << "Caught exception: " << e.what();
    } catch (...) {
        LOG(FATAL) << "Caught unknown exception.";
    }
}

static Status CreateNode(zhandle_t *handle, const std::string &path, const std::string& value,
        int mode, bool recursive,
        /*[out]*/std::string* path_created) {
    boost::scoped_array<char> buf;
    int buf_len = 0;
    if (path_created) {
        if (mode & mode::kPersistentSequence) {
            const int kSequenceSuffixLength = 11;
            buf_len = path.size() + kSequenceSuffixLength + 1;
        } else {
            buf_len = path.size() + 1;
        }
        buf.reset(new char[buf_len]);
    }

retry:
    Status status = zoo_create(handle, path.c_str(), value.data(), value.size(),
            &ZOO_OPEN_ACL_UNSAFE, mode, buf.get(), buf_len);
    if (status.ok()) {
        if (path_created) {
            path_created->assign(buf.get());
        }
    } else if (status.IsNoNode() && recursive) {
        std::string::size_type pos = path.rfind("/");
        CHECK_NE(pos, 0UL);
        CHECK_NE(pos, std::string::npos);
        std::string parent = path.substr(0, pos - 1);

        status = CreateNode(handle, parent, "", 0, true, NULL);
        if (!status.ok() && !status.IsNodeExists()) {
            return status;
        }
        goto retry;
    }
    return status;
}


/**
 * ZkCli
 */
ZkCli::ZkCli()
    : handle_(NULL)
{
}

ZkCli::~ZkCli()
{
    Close();
}

Status ZkCli::Init(const std::string &hosts, int timeout, Watcher *watcher) {
    CHECK_EQ(handle_, (void*)NULL);
    CHECK_GE(timeout, 0);

    Status status;

    zhandle_t *zh = zookeeper_init(hosts.c_str(), watcher ? ZkWatcher : NULL,
            timeout, NULL, watcher, 0);
    if (zh) {
        handle_ = zh;
    } else {
        status = errno;
    }
    return status;
}

Status ZkCli::Close() {
    Status status;
    if (handle_) {
        status = zookeeper_close(handle_);
        if (status.ok()) {
            handle_ = NULL;
        }
    }
    return status;
}

State ZkCli::state() {
    return zoo_state(handle_);
}

Status ZkCli::Create(const std::string &path,
        const std::string& value, int mode, 
        /*[out]*/ std::string* path_created) {
    return CreateNode(handle_, path, value, mode, false, path_created);
}

Status ZkCli::CreateRecursive(const std::string &path,
        const std::string &value, int mode,
        /*[out]*/ std::string* path_created) {
    return CreateNode(handle_, path, value, mode, true, path_created);
}

Status ZkCli::Delete(const std::string &path, int version) {
    Status status = zoo_delete(handle_, path.c_str(), version);
    return status;
}

Status ZkCli::DeleteRecursive(const std::string &path, int version) {
retry:
    Status status = zoo_delete(handle_, path.c_str(), version);
    if (status.IsNotEmpty()) {
        std::vector<std::string> childrens;
        status = GetChildren(path, NULL, &childrens);
        if (!status.ok()) {
            return status;
        }
        for (vector<string>::iterator it = childrens.begin();
                it != childrens.end(); ++it) {
            string child_path(path);
            if (child_path != "/") {
                child_path += "/";
            }
            child_path += *it;
            status = DeleteRecursive(child_path, -1);
            if (!status.ok() && !status.IsNoNode()) {
                return status;
            }
        }
        goto retry;
    }
    return status;
}

Status ZkCli::Exists(const std::string &path, Watcher *watcher,
        /*[out]*/ Stat *stat) {
    Status status = zoo_wexists(handle_, path.c_str(), watcher ? ZkWatcher : NULL, 
            watcher, stat);
    return status;
}

Status ZkCli::Get(const std::string &path, Watcher *watcher,
        /*[out]*/ std::string* value,
        /*[out]*/ Stat *stat) {
    CHECK_NOTNULL(value);

    const int kMaxDataLength = 1024 * 128;
    char buf[kMaxDataLength] = {};
    int buf_len = kMaxDataLength;

    Status status = zoo_wget(handle_, path.c_str(), watcher ? ZkWatcher : NULL,
            watcher, buf, &buf_len, stat);
    if (status.ok()) {
        if (buf_len > 0) {
            value->assign(buf, buf_len);
        } else {
            value->clear();
        }
    }
    return status;
}

Status ZkCli::Set(const std::string &path, const std::string& value, int version,
        /*[out]*/ Stat* stat) {
    Status status = zoo_set2(handle_, path.c_str(), value.data(), value.size(),
            version, stat);
    return status;
}

Status ZkCli::GetChildren(const std::string &path, Watcher *watcher,
        /*[out]*/ std::vector<std::string> *childrens) {
    return GetChildren2(path, watcher, childrens, NULL);
}

Status ZkCli::GetChildren2(const std::string &path, Watcher *watcher,
        /*[out]*/ std::vector<std::string> *childrens,
        /*[out]*/ Stat *stat) {
    CHECK_NOTNULL(childrens);

    Status status;
    struct String_vector sv = {};

    if (stat == NULL) {
        status = zoo_wget_children(handle_, path.c_str(), watcher ? ZkWatcher : NULL,
                watcher, &sv);
    } else {
        status = zoo_wget_children2(handle_, path.c_str(), watcher ? ZkWatcher : NULL,
                watcher, &sv, stat);
    }
    if (status.ok()) {
        for (int32_t i = 0; i < sv.count; ++i) {
            childrens->push_back(string(sv.data[i]));
        }
        deallocate_String_vector(&sv);
    }
    return status;
}


Status ZkCli::Create(const std::string &path,
        const std::string& value, int mode,
        const CreateCallback &callback) {
    std::auto_ptr<CallbackWrapperIf> wrapper(
            new CallbackWrapper<CreateResult>(path, callback));
    Status status = zoo_acreate(handle_, path.c_str(),
            value.data(), value.size(),
            &ZOO_OPEN_ACL_UNSAFE, mode,
            ZkCreateCompletion, wrapper.get());
    if (status.ok()) {
        wrapper.release();
    }
    return status;
}

Status ZkCli::CreateRecursive(const std::string &path,
        const std::string& value, int mode,
        const CreateCallback &callback) {
    /*
    std::auto_ptr<CallbackWrapperIf> wrapper(
            new CreateRecursiveCallbackWrapper(
                path, value, mode, callback, handle_));

    Status status = zoo_acreate(handle_, path.c_str(),
            value.data(), value.size(),
            &ZOO_OPEN_ACL_UNSAFE, mode,
            ZkCreateCompletion, wrapper.get());
    if (status.ok()) {
        wrapper.release();
    }
    return status;
    */
}

Status ZkCli::Delete(const std::string &path, int version,
        const DeleteCallback &callback) {
    std::auto_ptr<CallbackWrapperIf> wrapper(
            new CallbackWrapper<DeleteResult>(path, callback));

    Status status = zoo_adelete(handle_, path.c_str(), version,
        ZkDeleteCompletion, wrapper.get());
    if (status.ok()) {
        wrapper.release();
    }
    return status;
}

Status ZkCli::DeleteRecursive(const std::string &path, int version,
        const DeleteCallback &callback) {
    /*
    std::auto_ptr<CallbackWrapperIf> wrapper(
            new DeleteRecursiveCallbackWrapper(
                path, version, callback, handle_));

    Status status = zoo_adelete(handle_, path.c_str(), version,
        ZkDeleteCompletion, wrapper.get());
    if (status.ok()) {
        wrapper.release();
    }
    return status;
    */
}

Status ZkCli::Exists(const std::string &path, Watcher *watcher,
        const ExistsCallback &callback) {
    std::auto_ptr<CallbackWrapperIf> wrapper(
            new CallbackWrapper<ExistsResult>(path, callback));

    Status status = zoo_awexists(handle_, path.c_str(),
            watcher ? ZkWatcher : NULL, watcher,
            ZkExistsCompletion, wrapper.get());
    if (status.ok()) {
        wrapper.release();
    }
    return status;
}

Status ZkCli::Get(const std::string &path, Watcher *watcher,
        const GetCallback &callback) {
    std::auto_ptr<CallbackWrapperIf> wrapper(
            new CallbackWrapper<GetResult>(path, callback));

    Status status = zoo_awget(handle_, path.c_str(),
            watcher ? ZkWatcher : NULL, watcher,
            ZkGetCompletion, wrapper.get());
    if (status.ok()) {
        wrapper.release();
    }
    return status;
}

Status ZkCli::Set(const std::string &path, const std::string &value,
        int version,
        const SetCallback &callback) {
    std::auto_ptr<CallbackWrapperIf> wrapper(
            new CallbackWrapper<SetResult>(path, callback));

    Status status = zoo_aset(handle_, path.c_str(), value.data(), value.size(),
            version, ZkSetCompletion, wrapper.get());
    if (status.ok()) {
        wrapper.release();
    }
    return status;
}

Status ZkCli::GetChildren(const std::string &path, Watcher *watcher,
        const GetChildrenCallback &callback) {
    std::auto_ptr<CallbackWrapperIf> wrapper(
            new CallbackWrapper<GetChildrenResult>(path, callback));
    Status status = zoo_awget_children2(handle_, path.c_str(),
            watcher ? ZkWatcher : NULL, watcher,
            ZkGetChildrenCompletion, wrapper.get());
    if (status.ok()) {
        wrapper.release();
    }
    return status;
}

} // namespace zoocage
