/*
 * =============================================================================
 *
 *       Filename:  delete_wrapper.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  03/30/2012 19:25:31
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Xinjie Li (jasonli), xjason.li@gmail.com
 *        Company:  Qihoo inc.
 *
 * =============================================================================
 */

#ifndef ZKCLI_INTERNAL_DELETE_WRAPPER_H_
#define ZKCLI_INTERNAL_DELETE_WRAPPER_H_

#include <pthread.h>
#include "callback_wrapper.h"

namespace zoocage {

class DeleteRecursiveCallbackWrapperIf
    : public BasicCallbackWrapper<DeleteResult> {
public:
    virtual zhandle_t *zhandle() const = 0;
    virtual int version() const = 0;
protected:
    bool DoRecursive(Status status, Status *status2);
};

class GetChildrenAndDeleteCallbackWrapper
    : public BasicCallbackWrapper<GetChildrenResult> {
public:
    GetChildrenAndDeleteCallbackWrapper(
            DeleteRecursiveCallbackWrapperIf *parent)
        : parent_(parent) {}
    virtual const std::string &path() const { return parent_->path(); }
    virtual void ProcessResult(GetChildrenResult *result);
private:
    DeleteRecursiveCallbackWrapperIf *parent_;
};

class DeleteRecursiveCallbackWrapper
    : public DeleteRecursiveCallbackWrapperIf {
public:
    DeleteRecursiveCallbackWrapper(const std::string &path, int version, 
            const DeleteCallback& cb, zhandle_t *zh)
        : callback_(new CallbackWrapper<DeleteResult>(path, cb))
        , version_(version), zh_(zh) {}

    virtual const std::string &path() const { return callback_->path(); }
    virtual int version() const { return version_; }
    virtual zhandle_t *zhandle() const { return zh_; }
    virtual void ProcessResult(DeleteResult *result);
private:
    CallbackWrapper<DeleteResult> *callback_;
    int version_;
    zhandle_t *zh_;
};

class DeleteChildrenAggregator {
public:
    DeleteChildrenAggregator(const std::vector<std::string> &children);
    ~DeleteChildrenAggregator();

    bool ProcessChild(const std::string &path, const Status &status,
            Status *status2);

    int Ref();
    int Unref();
private:
    pthread_mutex_t mutex_;
    std::set<std::string> children_;
    Status status_;

    pthread_mutex_t ref_mtx_;
    int ref_;
};

class DeleteChildrenCallbackWrapper
    : public DeleteRecursiveCallbackWrapperIf {
public:
    DeleteChildrenCallbackWrapper(const std::string &path,
            DeleteRecursiveCallbackWrapperIf *parent,
            DeleteChildrenAggregator *aggr)
        : path_(path), parent_(parent), aggr_(aggr) { aggr_->Ref(); }
    ~DeleteChildrenCallbackWrapper() { aggr_->Unref(); }

    virtual const std::string &path() const { return path_; }
    virtual zhandle_t *zhandle() const { return parent_->zhandle(); }
    virtual int version() const { return -1; }
    virtual void ProcessResult(DeleteResult *result);
private:
    std::string path_;
    DeleteRecursiveCallbackWrapperIf *parent_;
    DeleteChildrenAggregator *aggr_;
};

} // namespace zoocage

#endif // ZKCLI_INTERNAL_DELETE_WRAPPERS_H_
