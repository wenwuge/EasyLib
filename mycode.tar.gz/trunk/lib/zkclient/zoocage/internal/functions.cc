#include "functions.h"
#include "logging.h"
#include "util.h"
#include "callback_wrapper.h"
#include "result_impl.h"
#include "zookeeper_impl.h"
#include "../watcher.h"

namespace zoocage {
namespace functions {

void Watcher1(zhandle_t *zh, int event, int state, const char *path,
        void *context) {
    CHECK_NOTNULL(context);

    std::string path2 = (path == NULL || event == ZOO_SESSION_EVENT
            || event == ZOO_NOTWATCHING_EVENT) ? "": path;

    ZooKeeperImpl* zk = static_cast<ZooKeeperImpl*>(context);
    uint32_t need_free = util::atomic_cas32(&(zk->free_initer_), 0, 1);
    if (need_free) {
        Synchronizer* initer = zk->initer_;
        zk->initer_ = NULL;
        CHECK_NOTNULL(initer);
        initer->Wait();
        delete initer;
    }
    Watcher* watcher = zk->watcher_;
    WatchedEvent watched_event(event, state, path2);
    try {
        watcher->Process(watched_event);
    } catch (const std::exception& e) {
        LOG(ERROR) << "Caught exception: " << e.what();
    } catch (...) {
        LOG(FATAL) << "Caught unknown exception.";
    }
}

void Watcher2(zhandle_t *zh, int event, int state, const char *path,
        void *context) {
    CHECK_NOTNULL(context);

    std::string path2 = (path == NULL || event == ZOO_SESSION_EVENT
            || event == ZOO_NOTWATCHING_EVENT) ? "": path;

    Watcher* watcher = (Watcher*)context;
    WatchedEvent watched_event(event, state, path2);
    try {
        watcher->Process(watched_event);
    } catch (const std::exception& e) {
        LOG(ERROR) << "Caught exception: " << e.what();
    } catch (...) {
        LOG(FATAL) << "Caught unknown exception.";
    }
}

void CreateCompletion(int rc, const char *name, const void *ptr) {
    CHECK_NOTNULL(ptr);
    CreateResultImpl result(rc, name, ptr);
    result.Process();
}

void DeleteCompletion(int rc, const void *ptr) {
    CHECK_NOTNULL(ptr);
    DeleteResultImpl result(rc, ptr);
    result.Process();
}

void ExistsCompletion(int rc, const struct ::Stat *stat,
        const void *ptr) {
    CHECK_NOTNULL(ptr);
    ExistsResultImpl result(rc, stat, ptr);
    result.Process();
}

void GetCompletion(int rc, const char *value, int value_len,
        const struct ::Stat *stat, const void *ptr) {
    CHECK_NOTNULL(ptr);
    GetResultImpl result(rc, value, value_len, stat, ptr);
    result.Process();
}

void SetCompletion(int rc, const struct ::Stat *stat,
        const void *ptr) {
    CHECK_NOTNULL(ptr);
    SetResultImpl result(rc, stat, ptr);
    result.Process();
}

void GetAclCompletion(int rc, const struct ::ACL_vector* acls, 
        const struct ::Stat* stat, const void *ptr) {
    CHECK_NOTNULL(ptr);
    GetAclResultImpl result(rc, acls, stat, ptr);
    result.Process();
}

void SetAclCompletion(int rc, const void* ptr) {
    CHECK_NOTNULL(ptr);
    SetAclResultImpl result(rc, ptr);
    result.Process();
}

void GetChildrenCompletion(int rc, const struct String_vector *strings,
        const void *ptr) {
    CHECK_NOTNULL(ptr);
    GetChildrenResultImpl result(rc, strings, ptr);
    result.Process();
}

void GetChildrenWithStatCompletion(int rc,
        const struct String_vector *strings, const struct ::Stat *stat,
        const void *ptr) {
    CHECK_NOTNULL(ptr);
    GetChildrenWithStatResultImpl result(rc, strings, stat, ptr);
    result.Process();
}

void AddAuthCompletion(int rc, const void* ptr) {
    CHECK_NOTNULL(ptr);
    AddAuthResultImpl result(rc, ptr);
    result.Process();
}

void MultiCompletion(int rc, const void* ptr) {
    CHECK_NOTNULL(ptr);
    MultiResultImpl result(rc, ptr);
    result.Process();
}

} // namespace functions
} // naemspace zoocage
