/*
 * =============================================================================
 *
 *       Filename:  logging.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  03/28/2012 11:34:57
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Xinjie Li (jasonli), xjason.li@gmail.com
 *        Company:  Qihoo inc.
 *
 * =============================================================================
 */

#ifndef ZKCLI_LOGGING_H_
#define ZKCLI_LOGGING_H_

#ifndef ZKCLI_NO_LOGGING
#include <glog/logging.h>
#else
#include <assert.h>
#define CHECK(x) assert(x)
#define CHECK_EQ(x, y) assert(x == y)
#define CHECK_NE(x, y) assert(x != y)
#define CHECK_LE(x, y) assert(x <= y)
#define CHECK_LT(x, y) assert(x < y)
#define CHECK_GE(x, y) assert(x >= y)
#define CHECK_GT(x, y) assert(x > y)

#endif


#endif // ZKCLI_LOGGING_H_
