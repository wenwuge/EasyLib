#ifndef ZOOCAGE_SYNCHRONIZER_H_
#define ZOOCAGE_SYNCHRONIZER_H_

#include <pthread.h>
#include <boost/shared_ptr.hpp>
#include "../result.h"
#include "op_result.h"

namespace zoocage {

class Synchronizer {
public:
    Synchronizer() : completed_(false) {
        pthread_cond_init(&cond_, NULL);
        pthread_mutex_init(&mutex_, NULL);
    }
    virtual ~Synchronizer() {
        pthread_mutex_destroy(&mutex_);
        pthread_cond_destroy(&cond_);
    }

    void Wait() {
        pthread_mutex_lock(&mutex_);
        while (!completed_) {
            pthread_cond_wait(&cond_, &mutex_);
        }
        pthread_mutex_unlock(&mutex_);
    }
    void Notify() {
        pthread_mutex_lock(&mutex_);
        completed_ = true;
        pthread_cond_broadcast(&cond_);
        pthread_mutex_unlock(&mutex_);
    }
private:
    pthread_cond_t cond_;
    pthread_mutex_t mutex_;
    bool completed_;
};

class SynchronizerCallbackBase {
public:
    SynchronizerCallbackBase() : sync_(new Synchronizer) {}
    Status Wait() { sync_->Wait(); return *status_; }
    void Notify() { sync_->Notify(); }
protected:
    boost::shared_ptr<Synchronizer> sync_;
    boost::shared_ptr<Status> status_;
};

template <class T>
struct SynchronizerCallback;

template <>
struct SynchronizerCallback<CreateResult> : public SynchronizerCallbackBase {
    SynchronizerCallback(std::string* path_created)
        : path_created_(path_created) {}
    void operator() (const CreateResult& result) {
        *status_ = result.status();
        *path_created_ = result.path_created();
        Notify();
    }
private:
    std::string* path_created_;
};

template <>
struct SynchronizerCallback<DeleteResult> : public SynchronizerCallbackBase {
    void operator() (const DeleteResult& result) {
        *status_ = result.status();
        Notify();
    }
};

template <>
struct SynchronizerCallback<ExistsResult> : public SynchronizerCallbackBase {
    SynchronizerCallback(Stat* stat) : stat_(stat) {}
    void operator() (const ExistsResult& result) {
        *status_ = result.status();
        *stat_ = result.stat();
        Notify();
    }
private:
    Stat* stat_;
};

template <>
struct SynchronizerCallback<GetResult> : public SynchronizerCallbackBase {
    SynchronizerCallback(std::string* data, Stat* stat)
        : data_(data), stat_(stat) {}
    void operator() (const GetResult& result) {
        *status_ = result.status();
        *data_ = result.data();
        *stat_ = result.stat();
        Notify();
    }
private:
    std::string* data_;
    Stat* stat_;
};

template <>
struct SynchronizerCallback<SetResult> : public SynchronizerCallbackBase {
    SynchronizerCallback(Stat* stat) : stat_(stat) {}
    void operator() (const SetResult& result) {
        *status_ = result.status();
        *stat_ = result.stat();
        Notify();
    }
private:
    Stat* stat_;
};

template <>
struct SynchronizerCallback<GetAclResult> : public SynchronizerCallbackBase {
    SynchronizerCallback(std::vector<Acl>* acls, Stat* stat)
        : acls_(acls), stat_(stat) {}
    void operator() (const GetAclResult& result) {
        *status_ = result.status();
        *acls_ = result.acls();
        *stat_ = result.stat();
        Notify();
    }
private:
    std::vector<Acl>* acls_;
    Stat* stat_;
};

template <>
struct SynchronizerCallback<SetAclResult> : public SynchronizerCallbackBase {
    void operator() (const SetAclResult& result) {
        *status_ = result.status();
        Notify();
    }
};

template <>
struct SynchronizerCallback<GetChildrenResult>
        : public SynchronizerCallbackBase {
    SynchronizerCallback(std::vector<std::string>* children)
        : children_(children) {}
    void operator() (const GetChildrenResult& result) {
        *status_ = result.status();
        *children_ = result.children();
        Notify();
    }
private:
    std::vector<std::string>* children_;
};

template <>
struct SynchronizerCallback<GetChildrenWithStatResult>
        : public SynchronizerCallbackBase {
    SynchronizerCallback(std::vector<std::string>* children, Stat* stat)
        : children_(children), stat_(stat) {}
    void operator() (const GetChildrenWithStatResult& result) {
        *status_ = result.status();
        *children_ = result.children();
        *stat_ = result.stat();
        Notify();
    }
private:
    std::vector<std::string>* children_;
    Stat* stat_;
};

template <>
struct SynchronizerCallback<AddAuthResult>
        : public SynchronizerCallbackBase {
    void operator() (const AddAuthResult& result) {
        *status_ = result.status();
        Notify();
    }
};

struct FakeOpResult : public Op::Result {
    FakeOpResult(Op::Type type, const Status& status, const std::string& path,
            const std::string* path_created,
            const Stat* stat_set)
        : type_(type), status_(status), path_(path)
        , path_created_(path_created ? new std::string(*path_created) : NULL)
        , stat_set_(stat_set ? new Stat(*stat_set) : NULL) {}
    ~FakeOpResult() {
        delete path_created_;
        delete stat_set_;
    }
    virtual Op::Type type() const { return type_; }
    virtual Status status() const { return status_; }
    virtual const std::string& path() const { return path_; }
    virtual const std::string* path_created() const { return path_created_; }
    virtual const Stat* stat_set() const { return stat_set_; }

    virtual void Update(int rc) {}
private:
    Op::Type type_;
    Status status_;
    std::string path_;
    std::string* path_created_;
    Stat* stat_set_;
};

template <>
struct SynchronizerCallback<MultiResult> : public SynchronizerCallbackBase {
    SynchronizerCallback(boost::ptr_vector<Op::Result>* results)
        : results_(results) {}
    void operator() (const MultiResult& result) {
        *status_ = result.status();
        boost::ptr_vector<Op::Result>::const_iterator it =
            result.results().begin();
        for (; it != result.results().end(); ++it) {
            results_->push_back(new FakeOpResult(it->type(), it->status(),
                        it->path(), it->path_created(), it->stat_set()));
        }
        Notify();
    }
private:
    boost::ptr_vector<Op::Result>* results_;
};
} // namespace zoocage

#endif // ZOOCAGE_SYNCHRONIZER_H_
