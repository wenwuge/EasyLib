/*
 * =============================================================================
 *
 *       Filename:  result_impl.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  03/31/2012 18:31:42
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Xinjie Li (jasonli), xjason.li@gmail.com
 *        Company:  Qihoo inc.
 *
 * =============================================================================
 */

#ifndef ZKCLI_INTERNAL_RESULT_IMPL_H_
#define ZKCLI_INTERNAL_RESULT_IMPL_H_

#include "../result.h"

namespace zoocage {

class ResultImplBase {
public:
    ResultImplBase(int rc) : status_(rc) {}
    virtual ~ResultImplBase() {}

    virtual void Process() = 0;
protected:
    Status status_;
};

template <class ResultT>
class ResultImpl : public ResultImplBase, public ResultT {
public:
    ResultImpl(int rc, const void *ptr)
        : ResultImplBase(rc)
        , callback_((CallbackWrapper<ResultT>*)ptr) {}

    virtual void Process() { callback_->ProcessResult(this); }
protected:
    CallbackWrapper<ResultT> *callback_;
};


class CreateResultImpl : public ResultImpl<CreateResult> {
public:
    CreateResultImpl(int rc, const char *value, const void *ptr)
        : ResultImpl<CreateResult>(rc, ptr)
    {
        if (status_.ok()) {
            path_created_.assign(value);
        }
    }
    virtual const Status &status() const { return status_; }
    virtual const std::string &path() const { return callback_->path(); }
    virtual const std::string &path_created() const { return path_created_; }
private:
    std::string path_created_;
};

class DeleteResultImpl : public ResultImpl<DeleteResult> {
public:
    DeleteResultImpl(int rc, const void *ptr)
        : ResultImpl<DeleteResult>(rc, ptr) {}
    virtual const Status &status() const { return status_; }
    virtual const std::string &path() const { return callback_->path(); }
};

class ExistsResultImpl : public ResultImpl<ExistsResult> {
public:
    ExistsResultImpl(int rc, const ::Stat *stat, const void *ptr)
        : ResultImpl<ExistsResult>(rc, ptr)
    {
        if (status_.ok()) {
            stat_ = *stat;
        }
    }
    virtual const Status &status() const { return status_; }
    virtual const std::string &path() const { return callback_->path(); }
    virtual const Stat &stat() const { return stat_; }
private:
    Stat stat_;
};

class GetResultImpl : public ResultImpl<GetResult> {
public:
    GetResultImpl(int rc, const char *value, int value_len,
            const ::Stat *stat, const void *ptr)
        : ResultImpl<GetResult>(rc, ptr)
    {
        if (status_.ok()) {
            data_.assign(value, value_len);
            stat_ = *stat;
        }
    }
    virtual const Status &status() const { return status_; }
    virtual const std::string &path() const { return callback_->path(); }
    virtual const std::string &data() const { return data_; }
    virtual const Stat &stat() const { return stat_; }
private:
    std::string data_;
    Stat stat_;
};

class SetResultImpl : public ResultImpl<SetResult> {
public:
    SetResultImpl(int rc, const ::Stat *stat, const void *ptr)
        : ResultImpl<SetResult>(rc, ptr)
    {
        if (status_.ok()) {
            stat_ = *stat;
        }
    }
    virtual const Status &status() const { return status_; }
    virtual const std::string &path() const { return callback_->path(); }
    virtual const Stat &stat() const { return stat_; }
private:
    Stat stat_;
};

class GetAclResultImpl : public ResultImpl<GetAclResult> {
public:
    GetAclResultImpl(int rc, const ::ACL_vector* acls, const ::Stat* stat,
            const void* ptr)
        : ResultImpl<GetAclResult>(rc, ptr)
    {
        if (status_.ok()) {
            std::copy(acls->data, acls->data + acls->count,
                    std::back_inserter(acls_));
            stat_ = *stat;
        }
    }
    virtual const Status& status() const { return status_; }
    virtual const std::string& path() const { return callback_->path(); }
    virtual const std::vector<Acl>& acls() const { return acls_; }
    virtual const Stat& stat() const { return stat_; }
private:
    std::vector<Acl> acls_;
    Stat stat_;
};

class SetAclResultImpl : public ResultImpl<SetAclResult> {
public:
    SetAclResultImpl(int rc, const void* ptr)
        : ResultImpl<SetAclResult>(rc, ptr) { }
    virtual const Status& status() const { return status_; }
    virtual const std::string& path() const { return callback_->path(); }
};

class GetChildrenResultImpl : public ResultImpl<GetChildrenResult> {
public:
    GetChildrenResultImpl(int rc, const String_vector *strings, const void *ptr)
        : ResultImpl<GetChildrenResult>(rc, ptr)
    {
        if (status_.ok()) {
            for (int32_t i = 0; i < strings->count; ++i) {
                children_.push_back(strings->data[i]);
            }
        }
    }
    virtual const Status &status() const { return status_; }
    virtual const std::string &path() const { return callback_->path(); }
    virtual const std::vector<std::string> &children() const { return children_; }
private:
    std::vector<std::string> children_;
};

class GetChildrenWithStatResultImpl : public ResultImpl<GetChildrenWithStatResult> {
public:
    GetChildrenWithStatResultImpl(int rc, const String_vector *strings, const ::Stat *stat,
            const void *ptr)
        : ResultImpl<GetChildrenWithStatResult>(rc, ptr)
    {
        if (status_.ok()) {
            for (int32_t i = 0; i < strings->count; ++i) {
                children_.push_back(strings->data[i]);
            }
            stat_ = *stat;
        }
    }
    virtual const Status &status() const { return status_; }
    virtual const std::string &path() const { return callback_->path(); }
    virtual const std::vector<std::string> &children() const { return children_; }
    virtual const Stat &stat() const { return stat_; }
private:
    std::vector<std::string> children_;
    Stat stat_;
};

class AddAuthResultImpl : public ResultImpl<AddAuthResult> {
public:
    AddAuthResultImpl(int rc, const void *ptr)
        : ResultImpl<AddAuthResult>(rc, ptr) {}
    virtual const Status &status() const { return status_; }
    virtual const std::string &scheme() const { return callback_->scheme(); }
    virtual const std::string &cert() const { return callback_->cert(); }
};

class MultiResultImpl : public ResultImpl<MultiResult> {
public:
    MultiResultImpl(int rc, const void* ptr)
        : ResultImpl<MultiResult>(rc, ptr) {}
    virtual const Status& status() const { return status_; }
    virtual const boost::ptr_vector<Op::Result>& results() const {
        return callback_->results(); 
    }
};

} // namespace zoocage

#endif // ZKCLI_INTERNAL_RESULT_IMPL_H_
