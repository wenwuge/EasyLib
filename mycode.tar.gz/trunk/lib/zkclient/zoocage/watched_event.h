/*
 * =============================================================================
 *
 *       Filename:  watched_event.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  03/26/2012 18:12:24
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Xinjie Li (jasonli), xjason.li@gmail.com
 *        Company:  Qihoo inc.
 *
 * =============================================================================
 */

#ifndef ZKCLI_WATCHED_EVENT_H_
#define ZKCLI_WATCHED_EVENT_H_

#include <string>
#include "state.h"
#include "event.h"

namespace zoocage {

class WatchedEvent {
public:
    WatchedEvent(const Event& event, const State &state,
            const std::string& path);

    const Event &event() const { return event_; }
    const State &state() const { return state_; }
    const std::string& path() const { return path_; }

    std::string ToString() const;
private:
    Event event_;
    State state_;
    std::string path_;
};

} // namespace zoocage

#endif // ZKCLI_WATCHED_EVENT_H_
