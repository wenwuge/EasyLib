#ifndef ZOOCAGE_OP_H_
#define ZOOCAGE_OP_H_

#include <assert.h>
#include <string>
#include <vector>
#include <boost/noncopyable.hpp>
#include <zookeeper/proto.h>
#include "status.h"
#include "acl.h"
#include "stat.h"
#include "mode.h"

namespace zoocage {

class OpCreate;
class OpDelete;
class OpSet;
class OpCheck;

class Op : boost::noncopyable {
public:
    enum Type {
        kCreate = ZOO_CREATE_OP,
        kDelete = ZOO_DELETE_OP,
        kSet = ZOO_SETDATA_OP,
        kCheck = ZOO_CHECK_OP,
    };
    class Result;
    virtual ~Op() {}
    
    virtual Result* MakeResult(zoo_op_t* zop) const = 0;
protected:
    friend class OpCreate;
    friend class OpDelete;
    friend class OpSet;
    friend class OpCheck;
    Op(const std::string& path);
    std::string path_;
};

class Op::Result : boost::noncopyable {
public:
    virtual ~Result() {}
    virtual Status status() const;
    virtual const std::string& path() const;
    virtual Type type() const = 0;
    virtual const std::string* path_created() const = 0;
    virtual const Stat* stat_set() const = 0;

    virtual void Update(int rc) = 0;
};


class OpCreate : public Op {
public:
    OpCreate(const std::string& path, const std::string& data,
        const std::vector<Acl>& acls, mode::Type mode);
    virtual ~OpCreate();
    virtual Result* MakeResult(zoo_op_t* zop) const;
private:
    std::string data_;
    ::ACL_vector acls_;
    mode::Type mode_;
};

class OpDelete : public Op {
public:
    OpDelete(const std::string& path, int32_t version);
    virtual Result* MakeResult(zoo_op_t* zop) const;
private:
    int32_t version_;
};

class OpSet : public Op {
public:
    OpSet(const std::string& path, const std::string& data, int32_t version);
    virtual Result* MakeResult(zoo_op_t* zop) const;
private:
    std::string data_;
    int32_t version_;
};

class OpCheck : public Op {
public:
    OpCheck(const std::string& path, int32_t version);
    virtual Result* MakeResult(zoo_op_t* zop) const;
private:
    int32_t version_;
};

} // namespace zoocage

#endif // ZOOCAGE_OP_H_
