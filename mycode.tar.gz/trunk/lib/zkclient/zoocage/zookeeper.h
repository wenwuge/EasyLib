#ifndef ZOOCAGE_ZOOKEEPER_H_
#define ZOOCAGE_ZOOKEEPER_H_

#include <string>
#include <vector>
#include <boost/ptr_container/ptr_vector.hpp>
#include <zookeeper/zookeeper.h>
#include "acl.h"
#include "mode.h"
#include "stat.h"
#include "status.h"
#include "watcher.h"
#include "callback.h"

namespace zoocage {

class ZooKeeperImpl;
class ZooKeeper {
public:
    ZooKeeper();
    ~ZooKeeper();

    Status Init(const std::string& dest, int timeout, Watcher* watcher);
    Status Close();

    Status AddAuth(const std::string& scheme, const std::string& cert);
    Status AddAuth(const std::string& scheme, const std::string& cert,
            const AddAuthCallback& callback);

    Status Create(const std::string& path, const std::string& data,
            const std::vector<Acl>& acls, mode::Type mode,
            std::string* path_created);
    Status Create(const std::string& path, const std::string& data,
            const std::vector<Acl>& acls, mode::Type mode,
            const CreateCallback& callback);

    Status Delete(const std::string& path, int32_t version);
    Status Delete(const std::string& path, int32_t version,
            const DeleteCallback& callback);

    Status Exists(const std::string& path, Watcher* watcher, Stat* stat);
    Status Exists(const std::string& path, bool watch, Stat* stat);
    Status Exists(const std::string& path, Watcher* watcher,
            const ExistsCallback& callback);
    Status Exists(const std::string& path, bool watch,
            const ExistsCallback& callback);

    Status Get(const std::string& path, Watcher* watcher, 
            std::string* data, Stat* stat);
    Status Get(const std::string& path, bool watch,
            std::string* data, Stat* stat);
    Status Get(const std::string& path, Watcher* watcher,
            const GetCallback& callback);
    Status Get(const std::string& path, bool watch,
            const GetCallback& callback);

    Status Set(const std::string& path, const std::string& data, int32_t version, 
            Stat* stat);
    Status Set(const std::string& path, const std::string& data, int32_t version,
            const SetCallback& callback);

    Status GetAcl(const std::string& path, std::vector<Acl>* acls,
            Stat* stat);
    Status GetAcl(const std::string& path, const GetAclCallback& callback);

    Status SetAcl(const std::string& path, const std::vector<Acl>& acls,
            int32_t version);
    Status SetAcl(const std::string& path, const std::vector<Acl>& acls,
            int32_t version, const SetAclCallback& callback);

    Status GetChildren(const std::string& path, Watcher* watcher,
            std::vector<std::string>* children);
    Status GetChildren(const std::string& path, bool watch,
            std::vector<std::string>* children);
    Status GetChildren(const std::string& path, Watcher* watcher,
            const GetChildrenCallback& callback);
    Status GetChildren(const std::string& path, bool watch,
            const GetChildrenCallback& callback);

    Status GetChildrenWithStat(const std::string& path, Watcher* watcher,
            std::vector<std::string>* children, Stat* stat);
    Status GetChildrenWithStat(const std::string& path, bool watch,
            std::vector<std::string>* children, Stat* stat);
    Status GetChildrenWithStat(const std::string& path, Watcher* watcher,
            const GetChildrenWithStatCallback& callback);
    Status GetChildrenWithStat(const std::string& path, bool watch,
            const GetChildrenWithStatCallback& callback);

    Status Multi(const boost::ptr_vector<Op>& ops,
            boost::ptr_vector<Op::Result>* results);
    Status Multi(const boost::ptr_vector<Op>& ops,
            const MultiCallback& callback);

private:
    // Disable copying
    ZooKeeper(const ZooKeeper&);
    ZooKeeper& operator = (const ZooKeeper&);

    ZooKeeperImpl* impl_;
};

} // end namespace zoocage

#endif // ZOOCAGE_ZOOKEEPER_H_
