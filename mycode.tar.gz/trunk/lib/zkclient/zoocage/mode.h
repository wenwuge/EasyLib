#ifndef ZOOCAGE_MODE_H_
#define ZOOCAGE_MODE_H_

#include <zookeeper/zookeeper.h>

namespace zoocage {

namespace mode {
    enum Type {
        kPersistent = 0,
        kEphemeral = 1,
        kPersistentSequence = 2,
        kEphemeralSequence = 3,
    };
    
    const char* ToString(Type mode);

} // namespace mode
} // namespace zoocage

#endif // ZOOCAGE_MODE_H_
