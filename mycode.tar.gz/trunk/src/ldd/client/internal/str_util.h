#ifndef __LDD_CLIENT_STRING_UTILITY__H_
#define __LDD_CLIENT_STRING_UTILITY__H_
#include <string>


namespace ldd {
namespace client {
namespace raw {


bool GetHostPost(const std::string& host_port, std::string& host, int & port);

} // namespace ldd {
} // namespace client {
} // namespace raw {

#endif 

