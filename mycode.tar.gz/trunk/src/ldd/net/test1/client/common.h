#ifndef __COMMON_H__
#define __COMMON_H__

void HeartBeat(int fd);
void Get(int fd);
void Put(int fd);

#endif /*__COMMON_H__*/

