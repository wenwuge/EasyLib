#include <glog/logging.h>
#include "common.h"

void Put(int fd)
{
    LOG(INFO) << "Put called";

    return;
}
