#include <stdio.h>
int main() {
    printf("%s\n", __PRETTY_FUNCTION__);
}
