// platform.h (2013-07-15)
// Li Xinjie (xjason.li@gmail.com)

#ifndef LDD_UTIL_DETAIL_ATOMIC_PLATFORM_H_
#define LDD_UTIL_DETAIL_ATOMIC_PLATFORM_H_

#if defined(__GNUC__) && (defined(__i386__) || defined(__x86_64__))
#   include "ldd/util/detail/atomic/gcc_x86.h"
#else
#   include "ldd/util/detail/atomic/base.h"
#endif

#endif // LDD_UTIL_DETAIL_ATOMIC_PLATFORM_H_
