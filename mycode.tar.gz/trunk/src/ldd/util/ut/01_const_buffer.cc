// 01_const_buffer.cc (2013-11-19)
// Li Xinjie (xjason.li@gmail.com)
//
#include <gtest/gtest.h>
#include <ldd/util/const_buffer.h>

class ConstBufferTest : public ::testing::Test {
protected:
    virtual void SetUp() {
    }
    virtual void TearDown() {
    }
};

