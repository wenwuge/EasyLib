

#ifndef __PROXY_TYPE_H__
#define __PROXY_TYPE_H__


enum CodeError{
    kOk     =  0,

    kProxyFailed       = -701,
    kProxyTimedOut     = -702,
    kProxyCanceled     = -703,

    kNotValidNameSpace = -704,
    kNotValidBucketId  = -705,
    kNotValidFarmId    = -706,
    
};

#endif /*__PROXY_TYPE_H__*/

