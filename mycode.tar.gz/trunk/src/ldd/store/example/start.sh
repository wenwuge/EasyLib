#!/bin/bash

../../skel/lddskel -n lddstore --cfg-dir=`pwd` --log-dir=`pwd`/log --pid-dir=`pwd` -f

