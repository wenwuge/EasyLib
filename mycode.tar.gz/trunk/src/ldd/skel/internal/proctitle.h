// proctitle.h (2013-08-01)
// Li Xinjie (xjason.li@gmail.com)

#ifndef LDD_SKEL_PROCTITLE_H_
#define LDD_SKEL_PROCTITLE_H_

#include <string>

namespace ldd {
namespace skel {

class ProcTitle {
public:
    static bool Init(int argc, char** argv);
    static void Set(const std::string& title);
};

} // namespace skel
} // namespace ldd

#endif // LDD_SKEL_PROCTITLE_H_
